#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Employee class for the Store Inventory and Order Management System.
"""

from typing import Optional, List, TYPE_CHECKING

from interfaces import StoreSystem

if TYPE_CHECKING:
    from product import Product
    from location import Location
    from product_location import ProductLocation
    from online_order import OnlineOrder
    from picking_session import PickingSession
    from restock_task import RestockTask


class Employee(StoreSystem):
    """
    Represents a store employee who can perform various operations.
    Implements the StoreSystem interface.
    
    Attributes:
        employee_id: Unique employee identifier
        password: Employee's password (hashed in production)
        name: Employee's name
        is_logged_in: Whether the employee is currently logged in
    """
    
    def __init__(
        self,
        employee_id: str = None,
        password: str = None,
        name: str = None
    ):
        self.employee_id = employee_id
        self.password = password
        self.name = name
        self.is_logged_in = False
        self._current_session: Optional['PickingSession'] = None
    
    def login(self, employee_id: str, password: str) -> bool:
        """
        Authenticate the employee.
        
        Args:
            employee_id: Employee ID to verify
            password: Password to verify
            
        Returns:
            True if authentication successful
        """
        if self.employee_id == employee_id and self.password == password:
            self.is_logged_in = True
            return True
        return False
    
    def logout(self) -> None:
        """Log out the employee."""
        self.is_logged_in = False
        self._current_session = None
    
    def pick_order(self, order: 'OnlineOrder') -> 'PickingSession':
        """
        Start picking an order.
        
        Args:
            order: The order to pick
            
        Returns:
            New PickingSession for this order
        """
        from picking_session import PickingSession
        
        if not self.is_logged_in:
            raise PermissionError("Employee must be logged in to pick orders")
        
        session = PickingSession(employee=self)
        session.add_order(order)
        self._current_session = session
        
        return session
    
    def stow_order(self, order: 'OnlineOrder', location: 'Location' = None) -> None:
        """
        Stow a completed order at a pickup location.
        
        Args:
            order: The order to stow
            location: Optional location to stow at
        """
        from enums import OrderStatus
        
        if not self.is_logged_in:
            raise PermissionError("Employee must be logged in to stow orders")
        
        if order.status != OrderStatus.READY:
            raise ValueError(f"Order must be READY to stow. Current: {order.status.value}")
        
        if location:
            order.assign_stow_location(location)
    
    def retrieve_order(self, customer_name: str) -> Optional['OnlineOrder']:
        """
        Retrieve an order for customer pickup.
        
        Args:
            customer_name: Name of the customer
            
        Returns:
            The order if found, None otherwise
        """
        from enums import OrderStatus
        
        if not self.is_logged_in:
            raise PermissionError("Employee must be logged in to retrieve orders")
        
        # This would typically search a database
        # For now, return None as we don't have a central order store
        return None
    
    def execute_restock(self, task: 'RestockTask') -> bool:
        """
        Execute a restock task.
        
        Args:
            task: The RestockTask to execute
            
        Returns:
            True if successful
        """
        if not self.is_logged_in:
            raise PermissionError("Employee must be logged in to execute restock")
        
        return task.execute()
    
    def update_location(self, location: 'ProductLocation', quantity: int) -> None:
        """
        Update the quantity at a product location.
        
        Args:
            location: The ProductLocation to update
            quantity: New quantity (can be positive or negative adjustment)
        """
        if not self.is_logged_in:
            raise PermissionError("Employee must be logged in to update locations")
        
        if quantity > 0:
            location.add_quantity(quantity)
        elif quantity < 0:
            location.remove_quantity(abs(quantity))
    
    def update_stock(self, product: 'Product', quantity: int) -> None:
        """
        Update the total stock of a product.
        
        Args:
            product: The product to update
            quantity: Quantity to add (positive) or remove (negative)
        """
        if not self.is_logged_in:
            raise PermissionError("Employee must be logged in to update stock")
        
        if quantity > 0:
            product.add_total_stock(quantity)
        elif quantity < 0:
            product.remove_total_stock(abs(quantity))
    
    def assign_product_to_location(
        self,
        product: 'Product',
        location: 'Location',
        max_qty: int
    ) -> 'ProductLocation':
        """
        Assign a product to a location.
        
        Args:
            product: Product to assign
            location: Location to assign to
            max_qty: Maximum quantity allowed at this location
            
        Returns:
            Created ProductLocation
        """
        from product_location import ProductLocation
        
        if not self.is_logged_in:
            raise PermissionError("Employee must be logged in to assign products")
        
        product_location = ProductLocation(
            product=product,
            location=location,
            quantity=0,
            max_quantity=max_qty
        )
        
        return product_location
    
    def get_current_session(self) -> Optional['PickingSession']:
        """Get the employee's current picking session."""
        return self._current_session
    
    def __repr__(self) -> str:
        return f"Employee(id='{self.employee_id}', name='{self.name}')"
    
    def __str__(self) -> str:
        status = "Logged In" if self.is_logged_in else "Logged Out"
        return f"{self.name} ({self.employee_id}) - {status}"
