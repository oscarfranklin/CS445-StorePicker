#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Location class for the Store Inventory and Order Management System.
"""

from typing import Optional, TYPE_CHECKING

from enums import LocationType

if TYPE_CHECKING:
    from product_location import ProductLocation


class Location:
    """
    Represents a physical location within the store.
    
    Attributes:
        location_id: Unique identifier for the location
        aisle: Aisle identifier
        section: Section within the aisle
        row: Row within the section
        placement_number: Specific placement number
        location_type: Type of location (SALESFLOOR, BACKROOM, ORDERPICKUP)
    """
    
    def __init__(
        self,
        location_id: str = None,
        aisle: str = None,
        section: str = None,
        row: str = None,
        placement_number: str = None,
        location_type: LocationType = None
    ):
        self.location_id = location_id
        self.aisle = aisle
        self.section = section
        self.row = row
        self.placement_number = placement_number
        self.location_type = location_type
        self._product_locations: list = []
    
    def get_full_location_string(self) -> str:
        """
        Get a formatted string representing the full location path.
        
        Returns:
            Formatted location string
        """
        parts = []
        if self.aisle:
            parts.append(f"Aisle {self.aisle}")
        if self.section:
            parts.append(f"Section {self.section}")
        if self.row:
            parts.append(f"Row {self.row}")
        if self.placement_number:
            parts.append(f"Placement {self.placement_number}")
        
        return " > ".join(parts) if parts else self.location_id or "Unknown Location"
    
    def add_product_location(self, product_location: 'ProductLocation') -> None:
        """
        Associate a ProductLocation with this location.
        
        Args:
            product_location: ProductLocation to associate
        """
        if product_location not in self._product_locations:
            self._product_locations.append(product_location)
    
    def get_product_locations(self) -> list:
        """
        Get all ProductLocations at this location.
        
        Returns:
            List of ProductLocation objects
        """
        return self._product_locations.copy()
    
    def is_salesfloor(self) -> bool:
        """Check if this is a salesfloor location."""
        return self.location_type == LocationType.SALESFLOOR
    
    def is_backroom(self) -> bool:
        """Check if this is a backroom location."""
        return self.location_type == LocationType.BACKROOM
    
    def is_order_pickup(self) -> bool:
        """Check if this is an order pickup location."""
        return self.location_type == LocationType.ORDERPICKUP
    
    def __repr__(self) -> str:
        return f"Location(id='{self.location_id}', type={self.location_type})"
    
    def __str__(self) -> str:
        type_str = self.location_type.value if self.location_type else "Unknown"
        return f"{type_str}: {self.get_full_location_string()}"
