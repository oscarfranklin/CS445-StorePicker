#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
PickingSession class for the Store Inventory and Order Management System.
"""

from datetime import datetime
from typing import List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from employee import Employee
    from online_order import OnlineOrder
    from order_item import OrderItem


class PickingSession:
    """
    Represents a session where an employee picks items for orders.
    
    Attributes:
        session_id: Unique session identifier
        employee: Employee performing the picking
        orders: Orders being picked in this session
        start_time: When the session started
        end_time: When the session ended
    """
    
    _session_counter = 0
    
    def __init__(
        self,
        session_id: str = None,
        employee: 'Employee' = None,
        start_time: datetime = None
    ):
        if session_id is None:
            PickingSession._session_counter += 1
            session_id = f"PICK-{PickingSession._session_counter:06d}"
        
        self.session_id = session_id
        self.employee = employee
        self.orders: List['OnlineOrder'] = []
        self.start_time = start_time or datetime.now()
        self.end_time: Optional[datetime] = None
        self._current_order_index = 0
        self._current_item_index = 0
    
    def add_order(self, order: 'OnlineOrder') -> None:
        """
        Add an order to this picking session.
        
        Args:
            order: Order to add
        """
        from enums import OrderStatus
        
        if order.status != OrderStatus.PENDING:
            raise ValueError(f"Order {order.order_id} is not in PENDING status")
        
        order.start_picking()
        self.orders.append(order)
    
    def get_next_item(self) -> Optional['OrderItem']:
        """
        Get the next item to pick.
        
        Returns:
            Next OrderItem to pick, or None if all done
        """
        while self._current_order_index < len(self.orders):
            order = self.orders[self._current_order_index]
            pending_items = order.get_pending_items()
            
            if pending_items:
                return pending_items[0]
            
            self._current_order_index += 1
        
        return None
    
    def pick_item(self, item: 'OrderItem') -> None:
        """
        Mark an item as found/picked.
        
        Args:
            item: The OrderItem that was picked
        """
        item.mark_found()
        
        # Reduce inventory from a location
        if item.product:
            locations = item.product.get_locations()
            remaining = item.quantity
            
            for loc in locations:
                if remaining <= 0:
                    break
                available = min(loc.quantity, remaining)
                if available > 0:
                    loc.remove_quantity(available)
                    remaining -= available
    
    def skip_item(self, item: 'OrderItem' = None) -> None:
        """
        Skip the current item being picked.
        
        Args:
            item: Optional specific item to skip
        """
        if item is None:
            item = self.get_next_item()
        
        if item:
            item.mark_skipped()
    
    def mark_item_not_found(self, item: 'OrderItem') -> None:
        """
        Mark an item as not found.
        
        Args:
            item: The OrderItem that was not found
        """
        item.mark_not_found()
    
    def complete(self) -> None:
        """Complete the picking session and finalize orders."""
        self.end_time = datetime.now()
        
        for order in self.orders:
            if order.all_items_processed():
                order.mark_ready()
    
    def get_progress(self) -> dict:
        """
        Get picking progress statistics.
        
        Returns:
            Dictionary with progress information
        """
        total_items = 0
        picked_items = 0
        not_found_items = 0
        skipped_items = 0
        
        for order in self.orders:
            for item in order.items:
                total_items += 1
                if item.is_found():
                    picked_items += 1
                elif item.status.value == "NOTFOUND":
                    not_found_items += 1
                elif item.status.value == "SKIPPED":
                    skipped_items += 1
        
        return {
            "total_items": total_items,
            "picked": picked_items,
            "not_found": not_found_items,
            "skipped": skipped_items,
            "pending": total_items - picked_items - not_found_items - skipped_items,
            "completion_percentage": (picked_items / total_items * 100) if total_items > 0 else 0
        }
    
    def __repr__(self) -> str:
        return f"PickingSession(id='{self.session_id}', orders={len(self.orders)})"
    
    def __str__(self) -> str:
        progress = self.get_progress()
        return f"Session {self.session_id}: {progress['picked']}/{progress['total_items']} items picked"
