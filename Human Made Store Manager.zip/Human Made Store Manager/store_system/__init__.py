#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Store Inventory and Order Management System

A comprehensive system for managing store inventory, locations, 
orders, and employee operations.

Classes:
    - Product: Represents products in inventory
    - Location: Physical store locations
    - ProductLocation: Association between products and locations
    - Customer: Store customers
    - OnlineOrder: Customer orders
    - OrderItem: Individual items in an order
    - Employee: Store employees
    - Administrator: Administrators with elevated privileges
    - PickingSession: Order picking sessions
    - RestockTask: Inventory restocking tasks

Enums:
    - LocationType: SALESFLOOR, BACKROOM, ORDERPICKUP
    - OrderStatus: PENDING, PICKING, READY, COMPLETED
    - ItemStatus: PENDING, FOUND, NOTFOUND, SKIPPED

Interfaces:
    - CustomerPortal: Interface for customer operations
    - StoreSystem: Interface for employee/admin operations
"""

from .enums import LocationType, OrderStatus, ItemStatus
from .interfaces import CustomerPortal, StoreSystem
from .product import Product
from .location import Location
from .product_location import ProductLocation
from .customer import Customer
from .online_order import OnlineOrder
from .order_item import OrderItem
from .employee import Employee
from .administrator import Administrator
from .picking_session import PickingSession
from .restock_task import RestockTask

__all__ = [
    # Enums
    'LocationType',
    'OrderStatus', 
    'ItemStatus',
    
    # Interfaces
    'CustomerPortal',
    'StoreSystem',
    
    # Core Classes
    'Product',
    'Location',
    'ProductLocation',
    'Customer',
    'OnlineOrder',
    'OrderItem',
    'Employee',
    'Administrator',
    'PickingSession',
    'RestockTask',
]

__version__ = '1.0.0'
__author__ = 'Store System Team'
