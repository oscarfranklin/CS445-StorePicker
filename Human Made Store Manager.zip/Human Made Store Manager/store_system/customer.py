#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Customer class for the Store Inventory and Order Management System.
"""

from typing import List, TYPE_CHECKING

from interfaces import CustomerPortal

if TYPE_CHECKING:
    from product import Product
    from online_order import OnlineOrder


class Customer(CustomerPortal):
    """
    Represents a customer who can browse products and place orders.
    Implements the CustomerPortal interface.
    
    Attributes:
        customer_id: Unique customer identifier
        name: Customer's name
        email: Customer's email address
        orders: List of orders placed by this customer
    """
    
    def __init__(
        self,
        customer_id: str = None,
        name: str = None,
        email: str = None
    ):
        self.customer_id = customer_id
        self.name = name
        self.email = email
        self.orders: List['OnlineOrder'] = []
    
    def browse_products(self) -> List['Product']:
        """
        Browse available products in the store.
        
        Returns:
            List of available products
        """
        from product import Product
        return [p for p in Product._products if p.total_stock > 0]
    
    def create_order(self) -> 'OnlineOrder':
        """
        Create a new online order for this customer.
        
        Returns:
            New OnlineOrder instance
        """
        from online_order import OnlineOrder
        
        order = OnlineOrder(customer=self)
        self.orders.append(order)
        return order
    
    def get_order_history(self) -> List['OnlineOrder']:
        """
        Get all orders placed by this customer.
        
        Returns:
            List of orders
        """
        return self.orders.copy()
    
    def get_pending_orders(self) -> List['OnlineOrder']:
        """
        Get orders that are still pending or in progress.
        
        Returns:
            List of pending orders
        """
        from enums import OrderStatus
        return [
            order for order in self.orders 
            if order.status in [OrderStatus.PENDING, OrderStatus.PICKING, OrderStatus.READY]
        ]
    
    def get_completed_orders(self) -> List['OnlineOrder']:
        """
        Get orders that have been completed.
        
        Returns:
            List of completed orders
        """
        from enums import OrderStatus
        return [order for order in self.orders if order.status == OrderStatus.COMPLETED]
    
    def __repr__(self) -> str:
        return f"Customer(id='{self.customer_id}', name='{self.name}')"
    
    def __str__(self) -> str:
        return f"{self.name} ({self.email})"
