#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Example usage of the Store Inventory and Order Management System.
Demonstrates the main features and workflows.
"""

from decimal import Decimal

# Import all classes
from enums import LocationType, OrderStatus, ItemStatus
from product import Product
from location import Location
from product_location import ProductLocation
from customer import Customer
from online_order import OnlineOrder
from employee import Employee
from administrator import Administrator
from picking_session import PickingSession
from restock_task import RestockTask


def main():
    print("=" * 60)
    print("Store Inventory and Order Management System Demo")
    print("=" * 60)
    
    # =========================================
    # 1. Administrator Setup
    # =========================================
    print("\n--- 1. Administrator Setup ---")
    
    admin = Administrator(
        admin_id="ADMIN001",
        employee_id="EMP001",
        password="admin123",
        name="John Admin"
    )
    
    # Login
    admin.login("EMP001", "admin123")
    print(f"Created and logged in: {admin}")
    
    # =========================================
    # 2. Create Products
    # =========================================
    print("\n--- 2. Create Products ---")
    
    products = [
        Product(
            sku="ELEC-001",
            name="Wireless Headphones",
            description="High-quality wireless headphones with noise cancellation",
            category="Electronics",
            price=Decimal("79.99"),
            total_stock=0
        ),
        Product(
            sku="ELEC-002", 
            name="USB-C Cable",
            description="6ft USB-C to USB-A cable",
            category="Electronics",
            price=Decimal("12.99"),
            total_stock=0
        ),
        Product(
            sku="HOME-001",
            name="Coffee Maker",
            description="12-cup programmable coffee maker",
            category="Home & Kitchen",
            price=Decimal("49.99"),
            total_stock=0
        )
    ]
    
    for product in products:
        admin.create_product(product)
        print(f"Created: {product}")
    
    # =========================================
    # 3. Create Locations
    # =========================================
    print("\n--- 3. Create Locations ---")
    
    # Salesfloor locations
    sf_loc1 = admin.create_location(
        location_id="SF-A1-01",
        aisle="A1",
        section="Electronics",
        row="1",
        placement_number="01",
        location_type=LocationType.SALESFLOOR
    )
    
    sf_loc2 = admin.create_location(
        location_id="SF-A2-01",
        aisle="A2",
        section="Home",
        row="1",
        placement_number="01",
        location_type=LocationType.SALESFLOOR
    )
    
    # Backroom locations
    br_loc1 = admin.create_location(
        location_id="BR-B1-01",
        aisle="B1",
        section="Storage",
        row="1",
        placement_number="01",
        location_type=LocationType.BACKROOM
    )
    
    # Order pickup location
    pickup_loc = admin.create_location(
        location_id="OP-001",
        aisle="Front",
        section="Pickup",
        row="1",
        placement_number="01",
        location_type=LocationType.ORDERPICKUP
    )
    
    print(f"Salesfloor: {sf_loc1}")
    print(f"Salesfloor: {sf_loc2}")
    print(f"Backroom: {br_loc1}")
    print(f"Pickup: {pickup_loc}")
    
    # =========================================
    # 4. Assign Products to Locations
    # =========================================
    print("\n--- 4. Assign Products to Locations ---")
    
    # Assign headphones to salesfloor
    headphones_sf = admin.assign_product_to_location(
        product=products[0],
        location=sf_loc1,
        max_qty=20
    )
    headphones_sf.add_quantity(15)
    
    # Assign headphones to backroom
    headphones_br = admin.assign_product_to_location(
        product=products[0],
        location=br_loc1,
        max_qty=100
    )
    headphones_br.add_quantity(50)
    
    # Assign USB cables to salesfloor
    cables_sf = admin.assign_product_to_location(
        product=products[1],
        location=sf_loc1,
        max_qty=50
    )
    cables_sf.add_quantity(30)
    
    # Assign coffee maker to salesfloor
    coffee_sf = admin.assign_product_to_location(
        product=products[2],
        location=sf_loc2,
        max_qty=10
    )
    coffee_sf.add_quantity(5)
    
    print(f"Headphones on salesfloor: {headphones_sf}")
    print(f"Headphones in backroom: {headphones_br}")
    print(f"USB cables: {cables_sf}")
    print(f"Coffee makers: {coffee_sf}")
    
    # =========================================
    # 5. Customer Creates Order
    # =========================================
    print("\n--- 5. Customer Creates Order ---")
    
    customer = Customer(
        customer_id="CUST001",
        name="Jane Smith",
        email="jane.smith@email.com"
    )
    
    # Browse products
    available_products = customer.browse_products()
    print(f"Available products: {len(available_products)}")
    for p in available_products:
        print(f"  - {p}")
    
    # Create an order
    order = customer.create_order()
    order.add_item(products[0], quantity=2)  # 2 headphones
    order.add_item(products[1], quantity=3)  # 3 USB cables
    
    order.purchase()
    print(f"\nOrder created: {order}")
    print(f"Order total: ${order.get_total()}")
    
    # =========================================
    # 6. Employee Picks Order
    # =========================================
    print("\n--- 6. Employee Picks Order ---")
    
    employee = Employee(
        employee_id="EMP002",
        password="emp123",
        name="Bob Worker"
    )
    employee.login("EMP002", "emp123")
    print(f"Employee logged in: {employee}")
    
    # Start picking
    session = employee.pick_order(order)
    print(f"Picking session started: {session}")
    
    # Pick items
    while True:
        item = session.get_next_item()
        if item is None:
            break
        print(f"  Picking: {item}")
        session.pick_item(item)
    
    # Complete session
    session.complete()
    print(f"\nSession completed: {session}")
    print(f"Progress: {session.get_progress()}")
    
    # =========================================
    # 7. Stow Order for Pickup
    # =========================================
    print("\n--- 7. Stow Order for Pickup ---")
    
    employee.stow_order(order, pickup_loc)
    print(f"Order stowed at: {pickup_loc}")
    print(f"Order status: {order.status.value}")
    
    # =========================================
    # 8. Restock Task
    # =========================================
    print("\n--- 8. Restock Task ---")
    
    # Check if salesfloor needs restock
    if headphones_sf.needs_restock():
        print("Headphones salesfloor location needs restock!")
    
    # Create restock task
    restock = RestockTask()
    needed = restock.calculate_restock_needs(
        salesfloor_location=headphones_sf,
        backroom_location=headphones_br,
        product=products[0]
    )
    print(f"Restock task created: {restock}")
    print(f"Quantity to restock: {needed}")
    
    # Execute restock
    if restock.can_execute():
        employee.execute_restock(restock)
        print(f"Restock completed!")
        print(f"Salesfloor now has: {headphones_sf.quantity}")
        print(f"Backroom now has: {headphones_br.quantity}")
    
    # =========================================
    # 9. Admin Reports
    # =========================================
    print("\n--- 9. Admin Reports ---")
    
    report = admin.generate_inventory_report()
    print("Inventory Report:")
    for key, value in report.items():
        print(f"  {key}: {value}")
    
    # =========================================
    # 10. Complete Order Pickup
    # =========================================
    print("\n--- 10. Complete Order Pickup ---")
    
    order.complete()
    print(f"Order completed! Final status: {order.status.value}")
    
    # Customer order history
    print(f"\nCustomer {customer.name}'s order history:")
    for o in customer.get_order_history():
        print(f"  {o}")
    
    print("\n" + "=" * 60)
    print("Demo completed successfully!")
    print("=" * 60)


if __name__ == "__main__":
    main()
