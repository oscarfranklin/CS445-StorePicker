ds#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
OrderItem class for the Store Inventory and Order Management System.
"""

from typing import TYPE_CHECKING

from enums import ItemStatus

if TYPE_CHECKING:
    from product import Product
    from online_order import OnlineOrder


class OrderItem:
    """
    Represents an individual item within an online order.
    
    Attributes:
        product: The product being ordered
        order: The parent order
        quantity: Quantity of this product ordered
        status: Current status of this item (PENDING, FOUND, NOTFOUND, SKIPPED)
    """
    
    def __init__(
        self,
        product: 'Product' = None,
        order: 'OnlineOrder' = None,
        quantity: int = 1,
        status: ItemStatus = ItemStatus.PENDING
    ):
        self.product = product
        self.order = order
        self.quantity = quantity
        self.status = status
    
    def mark_found(self) -> None:
        """Mark this item as found during picking."""
        self.status = ItemStatus.FOUND
    
    def mark_not_found(self) -> None:
        """Mark this item as not found during picking."""
        self.status = ItemStatus.NOTFOUND
    
    def mark_skipped(self) -> None:
        """Mark this item as skipped during picking."""
        self.status = ItemStatus.SKIPPED
    
    def mark_pending(self) -> None:
        """Reset this item to pending status."""
        self.status = ItemStatus.PENDING
    
    def is_found(self) -> bool:
        """Check if item has been found."""
        return self.status == ItemStatus.FOUND
    
    def is_pending(self) -> bool:
        """Check if item is still pending."""
        return self.status == ItemStatus.PENDING
    
    def get_line_total(self) -> float:
        """
        Calculate the total price for this line item.
        
        Returns:
            Total price (price * quantity)
        """
        if self.product and self.product.price:
            return float(self.product.price) * self.quantity
        return 0.0
    
    def __repr__(self) -> str:
        product_name = self.product.name if self.product else "None"
        return f"OrderItem(product='{product_name}', qty={self.quantity}, status={self.status.value})"
    
    def __str__(self) -> str:
        product_name = self.product.name if self.product else "Unknown Product"
        return f"{self.quantity}x {product_name} [{self.status.value}]"
