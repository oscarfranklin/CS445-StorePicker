#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Administrator class for the Store Inventory and Order Management System.
"""

from typing import List, TYPE_CHECKING

from employee import Employee
from interfaces import StoreSystem

if TYPE_CHECKING:
    from product import Product
    from location import Location


class Administrator(Employee, StoreSystem):
    """
    Represents a store administrator with elevated privileges.
    Extends Employee and implements StoreSystem interface.
    
    Administrators can perform all employee functions plus:
    - Manage locations
    - Create, edit, and remove products
    
    Attributes:
        admin_id: Unique administrator identifier (in addition to employee_id)
    """
    
    def __init__(
        self,
        admin_id: str = None,
        employee_id: str = None,
        password: str = None,
        name: str = None
    ):
        super().__init__(
            employee_id=employee_id,
            password=password,
            name=name
        )
        self.admin_id = admin_id
    
    def manage_locations(self, location: 'Location') -> None:
        """
        Manage a store location (create, update, or deactivate).
        
        Args:
            location: The location to manage
        """
        if not self.is_logged_in:
            raise PermissionError("Administrator must be logged in to manage locations")
        
        # Location management logic
        # This could include validation, updating location details, etc.
        pass
    
    def create_product(self, product: 'Product') -> 'Product':
        """
        Create a new product in the system.
        
        Args:
            product: The product to create
            
        Returns:
            The created product
        """
        from product import Product
        
        if not self.is_logged_in:
            raise PermissionError("Administrator must be logged in to create products")
        
        # Validate product
        if not product.sku:
            raise ValueError("Product must have a SKU")
        
        # Check for duplicate SKU
        existing = Product.search_by_sku(product.sku)
        if existing and existing != product:
            raise ValueError(f"Product with SKU {product.sku} already exists")
        
        return product
    
    def edit_product(self, product: 'Product', **kwargs) -> 'Product':
        """
        Edit an existing product.
        
        Args:
            product: The product to edit
            **kwargs: Fields to update (name, description, category, price)
            
        Returns:
            The updated product
        """
        if not self.is_logged_in:
            raise PermissionError("Administrator must be logged in to edit products")
        
        # Update allowed fields
        allowed_fields = ['name', 'description', 'category', 'price']
        for field, value in kwargs.items():
            if field in allowed_fields:
                setattr(product, field, value)
        
        return product
    
    def remove_product(self, product: 'Product') -> bool:
        """
        Remove a product from the system.
        
        Args:
            product: The product to remove
            
        Returns:
            True if removed successfully
        """
        from product import Product
        
        if not self.is_logged_in:
            raise PermissionError("Administrator must be logged in to remove products")
        
        # Check if product has stock
        if product.total_stock > 0:
            raise ValueError(
                f"Cannot remove product with existing stock. "
                f"Current stock: {product.total_stock}"
            )
        
        # Remove from product registry
        if product in Product._products:
            Product._products.remove(product)
            return True
        
        return False
    
    def create_location(
        self,
        location_id: str,
        aisle: str = None,
        section: str = None,
        row: str = None,
        placement_number: str = None,
        location_type = None
    ) -> 'Location':
        """
        Create a new store location.
        
        Args:
            location_id: Unique location identifier
            aisle: Aisle number/name
            section: Section identifier
            row: Row identifier
            placement_number: Specific placement
            location_type: Type of location
            
        Returns:
            The created Location
        """
        from location import Location
        
        if not self.is_logged_in:
            raise PermissionError("Administrator must be logged in to create locations")
        
        location = Location(
            location_id=location_id,
            aisle=aisle,
            section=section,
            row=row,
            placement_number=placement_number,
            location_type=location_type
        )
        
        return location
    
    def get_all_products(self) -> List['Product']:
        """
        Get all products in the system.
        
        Returns:
            List of all products
        """
        from product import Product
        return Product._products.copy()
    
    def generate_inventory_report(self) -> dict:
        """
        Generate an inventory report.
        
        Returns:
            Dictionary containing inventory statistics
        """
        from product import Product
        
        if not self.is_logged_in:
            raise PermissionError("Administrator must be logged in to generate reports")
        
        products = Product._products
        
        total_products = len(products)
        total_stock = sum(p.total_stock for p in products)
        out_of_stock = [p for p in products if p.total_stock == 0]
        low_stock = [p for p in products if 0 < p.total_stock < 10]
        
        return {
            "total_products": total_products,
            "total_stock_units": total_stock,
            "out_of_stock_count": len(out_of_stock),
            "out_of_stock_products": [p.name for p in out_of_stock],
            "low_stock_count": len(low_stock),
            "low_stock_products": [p.name for p in low_stock]
        }
    
    def __repr__(self) -> str:
        return f"Administrator(admin_id='{self.admin_id}', name='{self.name}')"
    
    def __str__(self) -> str:
        status = "Logged In" if self.is_logged_in else "Logged Out"
        return f"Admin: {self.name} ({self.admin_id}) - {status}"
