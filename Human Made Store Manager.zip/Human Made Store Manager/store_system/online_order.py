#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
OnlineOrder class for the Store Inventory and Order Management System.
"""

from datetime import datetime
from decimal import Decimal
from typing import List, Optional, TYPE_CHECKING

from enums import OrderStatus, ItemStatus

if TYPE_CHECKING:
    from product import Product
    from location import Location
    from order_item import OrderItem
    from customer import Customer


class OnlineOrder:
    """
    Represents an online order placed by a customer.
    
    Attributes:
        order_id: Unique order identifier
        customer: The customer who placed the order
        order_date: When the order was placed
        status: Current order status
        stow_location: Location where completed order is stored for pickup
        items: List of OrderItem objects in this order
    """
    
    _order_counter = 0
    
    def __init__(
        self,
        order_id: str = None,
        customer: 'Customer' = None,
        order_date: datetime = None,
        status: OrderStatus = OrderStatus.PENDING,
        stow_location: 'Location' = None
    ):
        if order_id is None:
            OnlineOrder._order_counter += 1
            order_id = f"ORD-{OnlineOrder._order_counter:06d}"
        
        self.order_id = order_id
        self.customer = customer
        self.order_date = order_date or datetime.now()
        self.status = status
        self.stow_location = stow_location
        self.items: List['OrderItem'] = []
    
    def add_item(self, product: 'Product', quantity: int = 1) -> 'OrderItem':
        """
        Add a product to the order.
        
        Args:
            product: Product to add
            quantity: Quantity to order
            
        Returns:
            The created OrderItem
        """
        from order_item import OrderItem
        
        # Check if product already in order
        for item in self.items:
            if item.product == product:
                item.quantity += quantity
                return item
        
        # Create new order item
        order_item = OrderItem(
            product=product,
            order=self,
            quantity=quantity
        )
        self.items.append(order_item)
        return order_item
    
    def remove_item(self, product: 'Product') -> bool:
        """
        Remove a product from the order.
        
        Args:
            product: Product to remove
            
        Returns:
            True if removed, False if not found
        """
        for i, item in enumerate(self.items):
            if item.product == product:
                del self.items[i]
                return True
        return False
    
    def purchase(self) -> bool:
        """
        Finalize the order for processing.
        
        Returns:
            True if purchase successful
        """
        if not self.items:
            raise ValueError("Cannot purchase an empty order")
        
        if self.status != OrderStatus.PENDING:
            raise ValueError(f"Order is not in PENDING status. Current: {self.status.value}")
        
        # Order remains in PENDING until picked
        return True
    
    def get_total(self) -> Decimal:
        """
        Calculate the total order amount.
        
        Returns:
            Total price of all items
        """
        total = Decimal("0.00")
        for item in self.items:
            if item.product and item.product.price:
                total += item.product.price * item.quantity
        return total
    
    def assign_stow_location(self, location: 'Location') -> None:
        """
        Assign a pickup location for the completed order.
        
        Args:
            location: Location where order will be stored
        """
        self.stow_location = location
    
    def start_picking(self) -> None:
        """Mark the order as being picked."""
        if self.status != OrderStatus.PENDING:
            raise ValueError(f"Cannot start picking. Order status: {self.status.value}")
        self.status = OrderStatus.PICKING
    
    def mark_ready(self) -> None:
        """Mark the order as ready for pickup."""
        if self.status != OrderStatus.PICKING:
            raise ValueError(f"Cannot mark ready. Order status: {self.status.value}")
        self.status = OrderStatus.READY
    
    def complete(self) -> None:
        """Mark the order as completed (picked up by customer)."""
        if self.status != OrderStatus.READY:
            raise ValueError(f"Cannot complete. Order status: {self.status.value}")
        self.status = OrderStatus.COMPLETED
    
    def get_pending_items(self) -> List['OrderItem']:
        """Get all items that haven't been picked yet."""
        return [item for item in self.items if item.status == ItemStatus.PENDING]
    
    def get_found_items(self) -> List['OrderItem']:
        """Get all items that have been found."""
        return [item for item in self.items if item.status == ItemStatus.FOUND]
    
    def get_not_found_items(self) -> List['OrderItem']:
        """Get all items that were not found."""
        return [item for item in self.items if item.status == ItemStatus.NOTFOUND]
    
    def all_items_processed(self) -> bool:
        """Check if all items have been processed (found, not found, or skipped)."""
        return all(item.status != ItemStatus.PENDING for item in self.items)
    
    def __repr__(self) -> str:
        return f"OnlineOrder(id='{self.order_id}', status={self.status.value}, items={len(self.items)})"
    
    def __str__(self) -> str:
        customer_name = self.customer.name if self.customer else "Guest"
        return f"Order {self.order_id} - {customer_name} - {self.status.value} - ${self.get_total()}"
