#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
RestockTask class for the Store Inventory and Order Management System.
"""

from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from product import Product
    from product_location import ProductLocation


class RestockTask:
    """
    Represents a task to restock a salesfloor location from the backroom.
    
    Attributes:
        task_id: Unique task identifier
        product: Product to restock
        salesfloor_location: Destination ProductLocation on salesfloor
        backroom_location: Source ProductLocation in backroom
        quantity_needed: Amount of product to move
        completed: Whether the task has been executed
    """
    
    _task_counter = 0
    
    def __init__(
        self,
        task_id: int = None,
        product: 'Product' = None,
        salesfloor_location: 'ProductLocation' = None,
        backroom_location: 'ProductLocation' = None,
        quantity_needed: int = 0
    ):
        if task_id is None:
            RestockTask._task_counter += 1
            task_id = RestockTask._task_counter
        
        self.task_id = task_id
        self.product = product
        self.salesfloor_location = salesfloor_location
        self.backroom_location = backroom_location
        self.quantity_needed = quantity_needed
        self.completed = False
    
    def calculate_restock_needs(
        self,
        salesfloor_location: 'ProductLocation',
        backroom_location: 'ProductLocation',
        product: 'Product'
    ) -> int:
        """
        Calculate how much product needs to be restocked.
        
        Args:
            salesfloor_location: The salesfloor ProductLocation
            backroom_location: The backroom ProductLocation
            product: The product to restock
            
        Returns:
            Quantity that should be restocked
        """
        self.product = product
        self.salesfloor_location = salesfloor_location
        self.backroom_location = backroom_location
        
        # Calculate how much space is available on salesfloor
        available_space = salesfloor_location.get_available_capacity()
        
        # Calculate how much is available in backroom
        available_stock = backroom_location.quantity
        
        # Restock amount is the minimum of what's needed and what's available
        self.quantity_needed = min(available_space, available_stock)
        
        return self.quantity_needed
    
    def execute(self) -> bool:
        """
        Execute the restock task - move inventory from backroom to salesfloor.
        
        Returns:
            True if successful, False otherwise
        """
        if self.completed:
            raise ValueError("Task has already been completed")
        
        if not self.salesfloor_location or not self.backroom_location:
            raise ValueError("Locations not set for restock task")
        
        if self.quantity_needed <= 0:
            self.completed = True
            return True
        
        # Check if backroom has enough stock
        if self.backroom_location.quantity < self.quantity_needed:
            raise ValueError(
                f"Insufficient backroom stock. Need {self.quantity_needed}, "
                f"have {self.backroom_location.quantity}"
            )
        
        # Check if salesfloor has enough capacity
        if self.salesfloor_location.get_available_capacity() < self.quantity_needed:
            raise ValueError(
                f"Insufficient salesfloor capacity. Need {self.quantity_needed}, "
                f"have {self.salesfloor_location.get_available_capacity()}"
            )
        
        # Remove from backroom (this also updates product total stock)
        self.backroom_location.remove_quantity(self.quantity_needed)
        
        # Add to salesfloor - but don't double-count in total stock
        # So we need to manually adjust without going through add_quantity
        self.salesfloor_location.quantity += self.quantity_needed
        
        # Re-add the stock we removed (since we're moving, not consuming)
        if self.product:
            self.product.add_total_stock(self.quantity_needed)
        
        self.completed = True
        return True
    
    def can_execute(self) -> bool:
        """
        Check if this task can be executed.
        
        Returns:
            True if task can be executed
        """
        if self.completed:
            return False
        
        if not self.salesfloor_location or not self.backroom_location:
            return False
        
        if self.quantity_needed <= 0:
            return True  # Nothing to do, but technically can complete
        
        # Check stock and capacity
        has_stock = self.backroom_location.quantity >= self.quantity_needed
        has_capacity = self.salesfloor_location.get_available_capacity() >= self.quantity_needed
        
        return has_stock and has_capacity
    
    def __repr__(self) -> str:
        product_name = self.product.name if self.product else "None"
        return f"RestockTask(id={self.task_id}, product='{product_name}', qty={self.quantity_needed})"
    
    def __str__(self) -> str:
        product_name = self.product.name if self.product else "Unknown Product"
        status = "Completed" if self.completed else "Pending"
        return f"Restock Task {self.task_id}: Move {self.quantity_needed} of {product_name} [{status}]"
