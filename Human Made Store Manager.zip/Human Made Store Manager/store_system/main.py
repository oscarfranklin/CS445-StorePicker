#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Store Inventory and Order Management System
Interactive Console Application

Features:
1. Product Locations (aisles, sections, rows, placements) - Admin can create/edit/remove
2. Product search by name or SKU with full info display
3. Products show their assigned store locations
4. Add/remove total stock when product selected
5. Location quantities with max limits
6. Restock tasks grouped by category with backroom-to-salesfloor transfer
7. Customer online ordering system
8. Employee login portal for store tasks
9. Order picking with Found/Not Found/Skip options
10. Order stowing at front pickup locations
11. Customer pickup by name lookup

Run: python main.py
"""

from decimal import Decimal, InvalidOperation
from datetime import datetime
from typing import List, Optional, Dict

from enums import LocationType, OrderStatus, ItemStatus
from product import Product
from location import Location
from product_location import ProductLocation
from customer import Customer
from online_order import OnlineOrder
from order_item import OrderItem
from employee import Employee
from administrator import Administrator
from picking_session import PickingSession
from restock_task import RestockTask


class StoreApplication:
    """Main application class that handles the interactive menu system."""
    
    def __init__(self):
        self.administrators: List[Administrator] = []
        self.employees: List[Employee] = []
        self.customers: List[Customer] = []
        self.locations: List[Location] = []
        self.orders: List[OnlineOrder] = []
        self.picking_sessions: List[PickingSession] = []
        self.restock_tasks: List[RestockTask] = []
        
        self.current_user = None
        self.current_user_type = None  # 'admin', 'employee', or 'customer'
        
        # Initialize with sample data
        self._create_sample_data()
    
    def _create_sample_data(self):
        """Create sample data for demonstration."""
        print("\n" + "=" * 60)
        print("  INITIALIZING STORE SYSTEM")
        print("=" * 60)
        
        # Create default admin
        admin = Administrator(
            admin_id="ADMIN001",
            employee_id="admin",
            password="admin",
            name="System Administrator"
        )
        admin.is_logged_in = True  # Auto-login for setup
        self.administrators.append(admin)
        
        # Create sample employees
        emp1 = Employee(employee_id="emp001", password="password", name="John Smith")
        emp2 = Employee(employee_id="emp002", password="password", name="Jane Doe")
        self.employees.append(emp1)
        self.employees.append(emp2)
        
        # Create sample customer
        cust = Customer(customer_id="CUST001", name="Bob Customer", email="bob@email.com")
        self.customers.append(cust)
        
        # Create store locations - SALESFLOOR
        sf_locations = [
            ("SF-A1-S1-R1-P1", "A1", "Electronics", "1", "1"),
            ("SF-A1-S1-R1-P2", "A1", "Electronics", "1", "2"),
            ("SF-A1-S2-R1-P1", "A1", "Electronics", "2", "1"),
            ("SF-A2-S1-R1-P1", "A2", "Home & Kitchen", "1", "1"),
            ("SF-A2-S1-R2-P1", "A2", "Home & Kitchen", "2", "1"),
            ("SF-A3-S1-R1-P1", "A3", "Grocery", "1", "1"),
            ("SF-A3-S1-R2-P1", "A3", "Grocery", "2", "1"),
        ]
        
        for loc_id, aisle, section, row, placement in sf_locations:
            loc = Location(
                location_id=loc_id,
                aisle=aisle,
                section=section,
                row=row,
                placement_number=placement,
                location_type=LocationType.SALESFLOOR
            )
            self.locations.append(loc)
        
        # Create store locations - BACKROOM
        br_locations = [
            ("BR-B1-S1-R1-P1", "B1", "Electronics Storage", "1", "1"),
            ("BR-B1-S1-R2-P1", "B1", "Electronics Storage", "2", "1"),
            ("BR-B2-S1-R1-P1", "B2", "Home Storage", "1", "1"),
            ("BR-B3-S1-R1-P1", "B3", "Grocery Storage", "1", "1"),
        ]
        
        for loc_id, aisle, section, row, placement in br_locations:
            loc = Location(
                location_id=loc_id,
                aisle=aisle,
                section=section,
                row=row,
                placement_number=placement,
                location_type=LocationType.BACKROOM
            )
            self.locations.append(loc)
        
        # Create ORDER PICKUP locations at front of store
        pickup_locations = [
            ("OP-F1-S1-R1-P1", "F1", "Order Pickup", "1", "1"),
            ("OP-F1-S1-R1-P2", "F1", "Order Pickup", "1", "2"),
            ("OP-F1-S1-R2-P1", "F1", "Order Pickup", "2", "1"),
            ("OP-F1-S1-R2-P2", "F1", "Order Pickup", "2", "2"),
            ("OP-F1-S1-R3-P1", "F1", "Order Pickup", "3", "1"),
        ]
        
        for loc_id, aisle, section, row, placement in pickup_locations:
            loc = Location(
                location_id=loc_id,
                aisle=aisle,
                section=section,
                row=row,
                placement_number=placement,
                location_type=LocationType.ORDERPICKUP
            )
            self.locations.append(loc)
        
        # Create sample products
        products_data = [
            ("ELEC-001", "Wireless Headphones", "Premium noise-cancelling headphones", "Electronics", "79.99"),
            ("ELEC-002", "USB-C Cable 6ft", "High-speed charging cable", "Electronics", "12.99"),
            ("ELEC-003", "Bluetooth Speaker", "Portable waterproof speaker", "Electronics", "49.99"),
            ("HOME-001", "Coffee Maker", "12-cup programmable coffee maker", "Home & Kitchen", "59.99"),
            ("HOME-002", "Toaster 4-Slice", "Stainless steel toaster", "Home & Kitchen", "34.99"),
            ("GROC-001", "Organic Coffee Beans", "1lb bag of premium beans", "Grocery", "14.99"),
            ("GROC-002", "Green Tea Box", "100 count tea bags", "Grocery", "8.99"),
        ]
        
        for sku, name, desc, category, price in products_data:
            product = Product(
                sku=sku,
                name=name,
                description=desc,
                category=category,
                price=Decimal(price),
                total_stock=0
            )
        
        # Assign products to locations with quantities
        # Get locations and products
        sf_elec1 = self._find_location("SF-A1-S1-R1-P1")
        sf_elec2 = self._find_location("SF-A1-S1-R1-P2")
        sf_home = self._find_location("SF-A2-S1-R1-P1")
        sf_groc = self._find_location("SF-A3-S1-R1-P1")
        
        br_elec = self._find_location("BR-B1-S1-R1-P1")
        br_home = self._find_location("BR-B2-S1-R1-P1")
        br_groc = self._find_location("BR-B3-S1-R1-P1")
        
        headphones = Product.search_by_sku("ELEC-001")
        usb_cable = Product.search_by_sku("ELEC-002")
        coffee_maker = Product.search_by_sku("HOME-001")
        coffee_beans = Product.search_by_sku("GROC-001")
        
        # Assign headphones to salesfloor and backroom
        if headphones and sf_elec1 and br_elec:
            pl1 = ProductLocation(product=headphones, location=sf_elec1, quantity=0, max_quantity=20)
            pl1.quantity = 5  # Low stock to demonstrate restock
            headphones.total_stock = 5
            
            pl2 = ProductLocation(product=headphones, location=br_elec, quantity=0, max_quantity=100)
            pl2.quantity = 50
            headphones.total_stock += 50
        
        # Assign USB cables
        if usb_cable and sf_elec2 and br_elec:
            pl1 = ProductLocation(product=usb_cable, location=sf_elec2, quantity=0, max_quantity=50)
            pl1.quantity = 30
            usb_cable.total_stock = 30
            
            pl2 = ProductLocation(product=usb_cable, location=br_elec, quantity=0, max_quantity=200)
            pl2.quantity = 100
            usb_cable.total_stock += 100
        
        # Assign coffee maker
        if coffee_maker and sf_home and br_home:
            pl1 = ProductLocation(product=coffee_maker, location=sf_home, quantity=0, max_quantity=10)
            pl1.quantity = 2  # Low stock
            coffee_maker.total_stock = 2
            
            pl2 = ProductLocation(product=coffee_maker, location=br_home, quantity=0, max_quantity=50)
            pl2.quantity = 25
            coffee_maker.total_stock += 25
        
        # Assign coffee beans
        if coffee_beans and sf_groc and br_groc:
            pl1 = ProductLocation(product=coffee_beans, location=sf_groc, quantity=0, max_quantity=30)
            pl1.quantity = 15
            coffee_beans.total_stock = 15
            
            pl2 = ProductLocation(product=coffee_beans, location=br_groc, quantity=0, max_quantity=100)
            pl2.quantity = 60
            coffee_beans.total_stock += 60
        
        admin.is_logged_in = False  # Reset login state
        
        print("\nSample data created successfully!")
        print("\n--- Login Credentials ---")
        print("  Administrator: admin / admin")
        print("  Employee 1: emp001 / password")
        print("  Employee 2: emp002 / password")
        print("  Customer: Bob Customer (select from menu)")
        print("\n--- Sample Data ---")
        print(f"  Locations: {len(self.locations)} (Salesfloor, Backroom, Order Pickup)")
        print(f"  Products: {len(Product._products)}")
        print(f"  Some products have LOW STOCK for restock demo")
    
    def _find_location(self, location_id: str) -> Optional[Location]:
        """Find a location by ID."""
        for loc in self.locations:
            if loc.location_id == location_id:
                return loc
        return None
    
    # ==================== UTILITY METHODS ====================
    
    def print_header(self, title: str):
        """Print a formatted header."""
        print("\n" + "=" * 60)
        print(f"  {title}")
        print("=" * 60)
    
    def print_subheader(self, title: str):
        """Print a formatted subheader."""
        print(f"\n--- {title} ---")
    
    def print_menu(self, options: dict):
        """Print menu options."""
        for key, value in options.items():
            print(f"  [{key}] {value}")
        print()
    
    def get_input(self, prompt: str, required: bool = True) -> str:
        """Get user input with optional validation."""
        while True:
            value = input(prompt).strip()
            if value or not required:
                return value
            print("  This field is required. Please try again.")
    
    def get_decimal_input(self, prompt: str) -> Decimal:
        """Get decimal input with validation."""
        while True:
            value = input(prompt).strip()
            try:
                return Decimal(value)
            except InvalidOperation:
                print("  Invalid number. Please enter a valid decimal (e.g., 29.99)")
    
    def get_int_input(self, prompt: str, min_val: int = None, max_val: int = None) -> int:
        """Get integer input with validation."""
        while True:
            value = input(prompt).strip()
            try:
                num = int(value)
                if min_val is not None and num < min_val:
                    print(f"  Value must be at least {min_val}")
                    continue
                if max_val is not None and num > max_val:
                    print(f"  Value must be at most {max_val}")
                    continue
                return num
            except ValueError:
                print("  Invalid number. Please enter a whole number.")
    
    def pause(self):
        """Pause and wait for user input."""
        input("\nPress Enter to continue...")
    
    def get_yes_no(self, prompt: str) -> bool:
        """Get yes/no input."""
        while True:
            value = input(prompt).strip().lower()
            if value in ['yes', 'y']:
                return True
            if value in ['no', 'n']:
                return False
            print("  Please enter 'yes' or 'no'")
    
    # ==================== MAIN MENU ====================
    
    def run(self):
        """Main application loop - starts with login."""
        # Show login menu first
        self.login_menu()
        
        # Main loop after initial login
        while True:
            self.print_header("STORE INVENTORY & ORDER MANAGEMENT SYSTEM")
            
            if self.current_user:
                user_type = self.current_user_type.upper()
                print(f"  Logged in as: {self.current_user.name} ({user_type})\n")
                
                options = {
                    "1": "Go to My Portal",
                    "2": "Switch User / Login",
                    "3": "View System Overview",
                    "0": "Exit System"
                }
            else:
                print("  Not logged in\n")
                options = {
                    "1": "Login",
                    "2": "View System Overview",
                    "0": "Exit System"
                }
            
            self.print_menu(options)
            
            choice = input("Select option: ").strip()
            
            if self.current_user:
                if choice == "1":
                    self._go_to_portal()
                elif choice == "2":
                    self.login_menu()
                elif choice == "3":
                    self.view_system_overview()
                elif choice == "0":
                    print("\nThank you for using the Store Management System. Goodbye!")
                    break
                else:
                    print("  Invalid option. Please try again.")
            else:
                if choice == "1":
                    self.login_menu()
                elif choice == "2":
                    self.view_system_overview()
                elif choice == "0":
                    print("\nThank you for using the Store Management System. Goodbye!")
                    break
                else:
                    print("  Invalid option. Please try again.")
    
    def _go_to_portal(self):
        """Redirect to the appropriate portal based on user type."""
        if isinstance(self.current_user, Administrator):
            self.admin_portal()
        elif isinstance(self.current_user, Employee):
            self.employee_portal()
        elif isinstance(self.current_user, Customer):
            self.customer_portal()
        else:
            print("  No portal available. Please login first.")
            self.pause()
    
    # ==================== LOGIN SYSTEM ====================
    
    def login_menu(self):
        """Handle user login - main entry point."""
        while True:
            self.print_header("LOGIN PORTAL")
            
            if self.current_user:
                print(f"  Currently logged in as: {self.current_user.name}")
                print()
            
            options = {
                "1": "Login as Administrator",
                "2": "Login as Employee",
                "3": "Login as Customer",
                "4": "Create New Customer Account",
            }
            self.print_menu(options)
            
            if self.current_user:
                print("  --- SESSION ---")
                session_options = {
                    "L": "Logout",
                    "0": "Back to Main Menu"
                }
                self.print_menu(session_options)
            else:
                print("  [0] Exit to Main Menu\n")
            
            choice = input("Select option: ").strip().upper()
            
            if choice == "1":
                self._login_admin()
                if self.current_user:
                    return  # Exit login menu after successful login
            elif choice == "2":
                self._login_employee()
                if self.current_user:
                    return  # Exit login menu after successful login
            elif choice == "3":
                self._login_customer()
                if self.current_user:
                    return  # Exit login menu after successful login
            elif choice == "4":
                self._create_customer_account()
            elif choice == "L" and self.current_user:
                self._logout_only()  # Just logout, stay in login menu
            elif choice == "0":
                return  # Back to main menu
    
    def _login_admin(self):
        """Administrator login."""
        self.print_subheader("Administrator Login")
        
        emp_id = self.get_input("Employee ID: ")
        password = self.get_input("Password: ")
        
        for admin in self.administrators:
            if admin.login(emp_id, password):
                self.current_user = admin
                self.current_user_type = "administrator"
                print(f"\n  Welcome, {admin.name}!")
                print("  Redirecting to Administrator Portal...")
                self.pause()
                self.admin_portal()  # Auto-redirect to portal
                return
        
        print("\n  Invalid credentials. Please try again.")
        self.pause()
    
    def _login_employee(self):
        """Employee login."""
        self.print_subheader("Employee Login")
        
        emp_id = self.get_input("Employee ID: ")
        password = self.get_input("Password: ")
        
        for emp in self.employees:
            if emp.login(emp_id, password):
                self.current_user = emp
                self.current_user_type = "employee"
                print(f"\n  Welcome, {emp.name}!")
                print("  Redirecting to Employee Portal...")
                self.pause()
                self.employee_portal()  # Auto-redirect to portal
                return
        
        print("\n  Invalid credentials. Please try again.")
        self.pause()
    
    def _login_customer(self):
        """Customer login by selection."""
        self.print_subheader("Customer Login")
        
        if not self.customers:
            print("  No customer accounts exist. Please create one first.")
            self.pause()
            return
        
        print("  Select your account:\n")
        for i, cust in enumerate(self.customers, 1):
            print(f"    {i}. {cust.name} ({cust.email})")
        print()
        
        choice = self.get_int_input("  Select customer number: ", 1, len(self.customers))
        self.current_user = self.customers[choice - 1]
        self.current_user_type = "customer"
        print(f"\n  Welcome, {self.current_user.name}!")
        print("  Redirecting to Customer Portal...")
        self.pause()
        self.customer_portal()  # Auto-redirect to portal
    
    def _create_customer_account(self):
        """Create new customer account."""
        self.print_subheader("Create Customer Account")
        
        cust_id = f"CUST{len(self.customers) + 1:03d}"
        name = self.get_input("  Full Name: ")
        email = self.get_input("  Email Address: ")
        
        customer = Customer(customer_id=cust_id, name=name, email=email)
        self.customers.append(customer)
        
        print(f"\n  Account created successfully!")
        print(f"  Customer ID: {cust_id}")
        print(f"  You can now login from the Customer Login menu.")
        self.pause()
    
    def _logout(self):
        """Logout current user and return to login menu."""
        if self.current_user:
            name = self.current_user.name
            if hasattr(self.current_user, 'logout'):
                self.current_user.logout()
            self.current_user = None
            self.current_user_type = None
            print(f"\n  {name} has been logged out.")
            self.pause()
            self.login_menu()  # Return to login menu
        else:
            print("\n  No user is currently logged in.")
            self.pause()
    
    def _logout_only(self):
        """Logout current user without redirecting."""
        if self.current_user:
            name = self.current_user.name
            if hasattr(self.current_user, 'logout'):
                self.current_user.logout()
            self.current_user = None
            self.current_user_type = None
            print(f"\n  {name} has been logged out.")
            print("  You can now login with a different account.")
            self.pause()
        else:
            print("\n  No user is currently logged in.")
            self.pause()
    
    # ==================== ADMINISTRATOR PORTAL ====================
    
    def admin_portal(self):
        """Administrator portal - includes all admin and employee features."""
        if not isinstance(self.current_user, Administrator):
            print("\n  Access Denied. Please login as Administrator first.")
            self.pause()
            return
        
        while True:
            self.print_header("ADMINISTRATOR PORTAL")
            print(f"  Logged in as: {self.current_user.name}\n")
            
            print("  --- ADMIN FUNCTIONS ---")
            options = {
                "1": "Manage Store Locations",
                "2": "Manage Products",
                "3": "Manage Inventory (Product Locations)",
                "4": "Manage Employees",
                "5": "View Reports",
                "6": "View All Orders",
            }
            self.print_menu(options)
            
            print("  --- EMPLOYEE FUNCTIONS ---")
            emp_options = {
                "7": "Search Product & Manage Stock",
                "8": "Pick Online Orders",
                "9": "Stow Completed Orders",
                "10": "Retrieve Customer Order (by Name)",
                "11": "Execute Restock",
                "12": "View Pending Orders",
            }
            self.print_menu(emp_options)
            
            print("  --- SESSION ---")
            session_options = {
                "L": "Logout",
                "0": "Back to Main Menu"
            }
            self.print_menu(session_options)
            
            choice = input("Select option: ").strip().upper()
            
            # Admin functions
            if choice == "1":
                self.admin_manage_locations()
            elif choice == "2":
                self.admin_manage_products()
            elif choice == "3":
                self.admin_manage_inventory()
            elif choice == "4":
                self.admin_manage_employees()
            elif choice == "5":
                self.admin_view_reports()
            elif choice == "6":
                self.admin_view_orders()
            # Employee functions (admins can do these too)
            elif choice == "7":
                self.employee_search_product()
            elif choice == "8":
                self.employee_pick_orders()
            elif choice == "9":
                self.employee_stow_orders()
            elif choice == "10":
                self.employee_retrieve_order()
            elif choice == "11":
                self.employee_restock()
            elif choice == "12":
                self.employee_view_pending_orders()
            # Session
            elif choice == "L":
                self._logout()
                return  # Exit portal after logout
            elif choice == "0":
                break
    
    # --- Location Management (Feature 1) ---
    
    def admin_manage_locations(self):
        """Manage store locations."""
        while True:
            self.print_header("MANAGE STORE LOCATIONS")
            print("  Locations consist of: Aisle > Section > Row > Placement\n")
            
            options = {
                "1": "View All Locations",
                "2": "View Locations by Type",
                "3": "Create New Location",
                "4": "Edit Location",
                "5": "Remove Location",
                "0": "Back"
            }
            self.print_menu(options)
            
            choice = input("Select option: ").strip()
            
            if choice == "1":
                self._view_all_locations()
            elif choice == "2":
                self._view_locations_by_type()
            elif choice == "3":
                self._create_location()
            elif choice == "4":
                self._edit_location()
            elif choice == "5":
                self._remove_location()
            elif choice == "0":
                break
    
    def _view_all_locations(self):
        """View all locations organized by type."""
        self.print_subheader("All Store Locations")
        
        for loc_type in LocationType:
            locs = [l for l in self.locations if l.location_type == loc_type]
            print(f"\n  {loc_type.value} ({len(locs)} locations):")
            print("  " + "-" * 56)
            
            if not locs:
                print("    No locations")
            else:
                print(f"    {'ID':<20} {'Aisle':<8} {'Section':<15} {'Row':<6} {'Place':<6}")
                print("    " + "-" * 52)
                for loc in locs:
                    print(f"    {loc.location_id:<20} {loc.aisle or '-':<8} {loc.section or '-':<15} {loc.row or '-':<6} {loc.placement_number or '-':<6}")
        
        self.pause()
    
    def _view_locations_by_type(self):
        """View locations filtered by type."""
        self.print_subheader("View Locations by Type")
        
        print("  1. SALESFLOOR - Customer shopping area")
        print("  2. BACKROOM - Storage area")
        print("  3. ORDERPICKUP - Front of store for order pickup\n")
        
        choice = self.get_int_input("  Select type: ", 1, 3)
        loc_types = [LocationType.SALESFLOOR, LocationType.BACKROOM, LocationType.ORDERPICKUP]
        selected_type = loc_types[choice - 1]
        
        locs = [l for l in self.locations if l.location_type == selected_type]
        
        print(f"\n  {selected_type.value} Locations ({len(locs)}):")
        print("  " + "-" * 56)
        
        if not locs:
            print("    No locations of this type")
        else:
            print(f"    {'ID':<20} {'Aisle':<8} {'Section':<15} {'Row':<6} {'Place':<6}")
            print("    " + "-" * 52)
            for loc in locs:
                print(f"    {loc.location_id:<20} {loc.aisle or '-':<8} {loc.section or '-':<15} {loc.row or '-':<6} {loc.placement_number or '-':<6}")
                
                # Show products at this location
                product_locs = loc.get_product_locations()
                for pl in product_locs:
                    print(f"      -> {pl.product.name}: {pl.quantity}/{pl.max_quantity}")
        
        self.pause()
    
    def _create_location(self):
        """Create a new location."""
        self.print_subheader("Create New Location")
        
        print("  Location Type:")
        print("    1. SALESFLOOR - Customer shopping area")
        print("    2. BACKROOM - Storage area")
        print("    3. ORDERPICKUP - Front of store for order pickup\n")
        
        type_choice = self.get_int_input("  Select type: ", 1, 3)
        loc_types = [LocationType.SALESFLOOR, LocationType.BACKROOM, LocationType.ORDERPICKUP]
        location_type = loc_types[type_choice - 1]
        
        print(f"\n  Creating {location_type.value} location...")
        print("  Enter location details:\n")
        
        aisle = self.get_input("  Aisle (e.g., A1, B2, F1): ")
        section = self.get_input("  Section (e.g., Electronics, Storage): ")
        row = self.get_input("  Row number: ")
        placement = self.get_input("  Placement number: ")
        
        # Generate location ID
        prefix = {"SALESFLOOR": "SF", "BACKROOM": "BR", "ORDERPICKUP": "OP"}
        loc_id = f"{prefix[location_type.value]}-{aisle}-{section[:2].upper()}-R{row}-P{placement}"
        
        # Check for duplicate
        if self._find_location(loc_id):
            print(f"\n  Error: Location ID '{loc_id}' already exists!")
            self.pause()
            return
        
        location = Location(
            location_id=loc_id,
            aisle=aisle,
            section=section,
            row=row,
            placement_number=placement,
            location_type=location_type
        )
        self.locations.append(location)
        
        print(f"\n  Location created successfully!")
        print(f"  ID: {loc_id}")
        print(f"  Full path: {location.get_full_location_string()}")
        self.pause()
    
    def _edit_location(self):
        """Edit an existing location."""
        self.print_subheader("Edit Location")
        
        if not self.locations:
            print("  No locations to edit.")
            self.pause()
            return
        
        loc_id = self.get_input("  Enter Location ID to edit: ")
        location = self._find_location(loc_id)
        
        if not location:
            print(f"  Location '{loc_id}' not found.")
            self.pause()
            return
        
        print(f"\n  Editing: {location}")
        print(f"  Current: Aisle={location.aisle}, Section={location.section}, Row={location.row}, Placement={location.placement_number}")
        print("\n  Press Enter to keep current value:\n")
        
        new_aisle = input(f"  Aisle [{location.aisle}]: ").strip()
        new_section = input(f"  Section [{location.section}]: ").strip()
        new_row = input(f"  Row [{location.row}]: ").strip()
        new_placement = input(f"  Placement [{location.placement_number}]: ").strip()
        
        if new_aisle:
            location.aisle = new_aisle
        if new_section:
            location.section = new_section
        if new_row:
            location.row = new_row
        if new_placement:
            location.placement_number = new_placement
        
        print(f"\n  Location updated!")
        print(f"  New path: {location.get_full_location_string()}")
        self.pause()
    
    def _remove_location(self):
        """Remove a location."""
        self.print_subheader("Remove Location")
        
        if not self.locations:
            print("  No locations to remove.")
            self.pause()
            return
        
        loc_id = self.get_input("  Enter Location ID to remove: ")
        location = self._find_location(loc_id)
        
        if not location:
            print(f"  Location '{loc_id}' not found.")
            self.pause()
            return
        
        # Check if location has products
        product_locs = location.get_product_locations()
        if product_locs:
            print(f"\n  Warning: This location has {len(product_locs)} product(s) assigned:")
            for pl in product_locs:
                print(f"    - {pl.product.name}: {pl.quantity} units")
            print("\n  You must reassign or remove these products first.")
            self.pause()
            return
        
        if self.get_yes_no(f"  Remove location '{loc_id}'? (yes/no): "):
            self.locations.remove(location)
            print("  Location removed successfully!")
        else:
            print("  Removal cancelled.")
        
        self.pause()
    
    # --- Product Management (Features 2, 3, 4) ---
    
    def admin_manage_products(self):
        """Manage products."""
        while True:
            self.print_header("MANAGE PRODUCTS")
            
            options = {
                "1": "View All Products",
                "2": "Search Product (by Name or SKU)",
                "3": "Create New Product",
                "4": "Edit Product",
                "5": "Delete Product",
                "0": "Back"
            }
            self.print_menu(options)
            
            choice = input("Select option: ").strip()
            
            if choice == "1":
                self._view_all_products()
            elif choice == "2":
                self._search_product()
            elif choice == "3":
                self._create_product()
            elif choice == "4":
                self._edit_product()
            elif choice == "5":
                self._delete_product()
            elif choice == "0":
                break
    
    def _view_all_products(self):
        """View all products."""
        self.print_subheader("All Products")
        
        if not Product._products:
            print("  No products in system.")
        else:
            print(f"  {'SKU':<12} {'Name':<25} {'Category':<15} {'Price':>10} {'Stock':>8}")
            print("  " + "-" * 72)
            for p in Product._products:
                print(f"  {p.sku:<12} {p.name:<25} {p.category or 'N/A':<15} ${p.price:>9} {p.total_stock:>8}")
        
        self.pause()
    
    def _search_product(self):
        """Search product by name or SKU (Feature 2)."""
        self.print_subheader("Search Product")
        
        print("  1. Search by SKU")
        print("  2. Search by Name (partial match)\n")
        
        choice = self.get_int_input("  Select search type: ", 1, 2)
        
        if choice == 1:
            search_term = self.get_input("  Enter SKU: ")
            product = Product.search_by_sku(search_term)
        else:
            search_term = self.get_input("  Enter name (or part of name): ")
            product = Product.search_by_name(search_term)
        
        if product:
            self._display_product_details(product)
        else:
            print("\n  Product not found.")
        
        self.pause()
    
    def _display_product_details(self, product: Product):
        """Display full product details including locations (Features 2, 3)."""
        print("\n  " + "=" * 50)
        print(f"  PRODUCT DETAILS")
        print("  " + "=" * 50)
        print(f"  SKU:         {product.sku}")
        print(f"  Name:        {product.name}")
        print(f"  Description: {product.description or 'N/A'}")
        print(f"  Category:    {product.category or 'N/A'}")
        print(f"  Price:       ${product.price}")
        print(f"  Total Stock: {product.total_stock}")
        
        # Show locations (Feature 3)
        locations = product.get_locations()
        total_at_locations = sum(pl.quantity for pl in locations) if locations else 0
        available_to_distribute = product.total_stock - total_at_locations
        
        print(f"\n  STOCK DISTRIBUTION:")
        print(f"    At locations:    {total_at_locations}")
        print(f"    Undistributed:   {available_to_distribute}")
        
        if locations:
            print("\n  STORE LOCATIONS:")
            print("  " + "-" * 46)
            for pl in locations:
                loc_type = pl.location.location_type.value if pl.location.location_type else "N/A"
                fill_pct = (pl.quantity / pl.max_quantity * 100) if pl.max_quantity > 0 else 0
                print(f"    {loc_type:<12} {pl.location.location_id:<20}")
                print(f"               Qty: {pl.quantity}/{pl.max_quantity} ({fill_pct:.0f}% full)")
                print(f"               Path: {pl.location.get_full_location_string()}")
        else:
            print("\n  No store locations assigned.")
    
    def _create_product(self):
        """Create a new product."""
        self.print_subheader("Create New Product")
        
        sku = self.get_input("  SKU: ")
        
        if Product.search_by_sku(sku):
            print(f"  Error: Product with SKU '{sku}' already exists!")
            self.pause()
            return
        
        name = self.get_input("  Product Name: ")
        description = self.get_input("  Description: ", required=False)
        category = self.get_input("  Category: ")
        price = self.get_decimal_input("  Price: $")
        
        product = Product(
            sku=sku,
            name=name,
            description=description,
            category=category,
            price=price,
            total_stock=0
        )
        
        print(f"\n  Product '{name}' created successfully!")
        print("  Note: Assign this product to locations to add stock.")
        self.pause()
    
    def _edit_product(self):
        """Edit a product."""
        self.print_subheader("Edit Product")
        
        sku = self.get_input("  Enter SKU of product to edit: ")
        product = Product.search_by_sku(sku)
        
        if not product:
            print("  Product not found.")
            self.pause()
            return
        
        self._display_product_details(product)
        
        print("\n  Press Enter to keep current value:\n")
        
        new_name = input(f"  Name [{product.name}]: ").strip()
        new_desc = input(f"  Description [{product.description}]: ").strip()
        new_cat = input(f"  Category [{product.category}]: ").strip()
        new_price = input(f"  Price [{product.price}]: ").strip()
        
        if new_name:
            product.name = new_name
        if new_desc:
            product.description = new_desc
        if new_cat:
            product.category = new_cat
        if new_price:
            try:
                product.price = Decimal(new_price)
            except:
                print("  Invalid price, keeping original.")
        
        print("\n  Product updated successfully!")
        self.pause()
    
    def _delete_product(self):
        """Delete a product."""
        self.print_subheader("Delete Product")
        
        sku = self.get_input("  Enter SKU of product to delete: ")
        product = Product.search_by_sku(sku)
        
        if not product:
            print("  Product not found.")
            self.pause()
            return
        
        if product.total_stock > 0:
            print(f"\n  Cannot delete product with existing stock ({product.total_stock} units).")
            print("  Remove all stock first.")
            self.pause()
            return
        
        if self.get_yes_no(f"  Delete '{product.name}'? (yes/no): "):
            Product._products.remove(product)
            print("  Product deleted successfully!")
        else:
            print("  Deletion cancelled.")
        
        self.pause()
    
    # --- Inventory Management (Features 4, 5, 6) ---
    
    def admin_manage_inventory(self):
        """Manage product-location assignments and stock."""
        while True:
            self.print_header("MANAGE INVENTORY")
            
            options = {
                "1": "View All Product Locations",
                "2": "Assign Product to Location",
                "3": "Update Product Total Stock",
                "4": "Update Location Quantity",
                "5": "Generate Restock Report (by Category)",
                "0": "Back"
            }
            self.print_menu(options)
            
            choice = input("Select option: ").strip()
            
            if choice == "1":
                self._view_all_product_locations()
            elif choice == "2":
                self._assign_product_to_location()
            elif choice == "3":
                self._update_product_total_stock()
            elif choice == "4":
                self._update_location_quantity()
            elif choice == "5":
                self._generate_restock_report()
            elif choice == "0":
                break
    
    def _view_all_product_locations(self):
        """View all product-location assignments."""
        self.print_subheader("All Product Locations")
        
        all_product_locs = []
        for product in Product._products:
            all_product_locs.extend(product.get_locations())
        
        if not all_product_locs:
            print("  No product locations configured.")
        else:
            print(f"  {'Product':<20} {'Location':<15} {'Type':<12} {'Qty':>6} {'Max':>6} {'Fill':>7}")
            print("  " + "-" * 70)
            for pl in all_product_locs:
                pname = pl.product.name[:19] if pl.product else "N/A"
                loc_id = pl.location.location_id[:14] if pl.location else "N/A"
                loc_type = pl.location.location_type.value[:11] if pl.location and pl.location.location_type else "N/A"
                fill = f"{(pl.quantity/pl.max_quantity*100):.0f}%" if pl.max_quantity > 0 else "N/A"
                print(f"  {pname:<20} {loc_id:<15} {loc_type:<12} {pl.quantity:>6} {pl.max_quantity:>6} {fill:>7}")
        
        self.pause()
    
    def _assign_product_to_location(self):
        """Assign a product to a location."""
        self.print_subheader("Assign Product to Location")
        
        if not Product._products:
            print("  No products available. Create a product first.")
            self.pause()
            return
        
        if not self.locations:
            print("  No locations available. Create a location first.")
            self.pause()
            return
        
        # Select product
        print("  Available Products:")
        for i, p in enumerate(Product._products, 1):
            print(f"    {i}. {p.name} (SKU: {p.sku})")
        print()
        
        prod_idx = self.get_int_input("  Select product: ", 1, len(Product._products))
        product = Product._products[prod_idx - 1]
        
        # Select location type
        print("\n  Location Type:")
        print("    1. SALESFLOOR")
        print("    2. BACKROOM")
        print()
        
        type_choice = self.get_int_input("  Select type: ", 1, 2)
        loc_type = LocationType.SALESFLOOR if type_choice == 1 else LocationType.BACKROOM
        
        # Show available locations of that type
        available_locs = [l for l in self.locations if l.location_type == loc_type]
        
        if not available_locs:
            print(f"  No {loc_type.value} locations available.")
            self.pause()
            return
        
        print(f"\n  Available {loc_type.value} Locations:")
        for i, loc in enumerate(available_locs, 1):
            print(f"    {i}. {loc.location_id} - {loc.get_full_location_string()}")
        print()
        
        loc_idx = self.get_int_input("  Select location: ", 1, len(available_locs))
        location = available_locs[loc_idx - 1]
        
        # Check if already assigned
        for pl in product.get_locations():
            if pl.location == location:
                print(f"\n  Product is already assigned to this location.")
                self.pause()
                return
        
        max_qty = self.get_int_input("  Maximum quantity for this location: ", 1)
        initial_qty = self.get_int_input(f"  Initial quantity (0-{max_qty}): ", 0, max_qty)
        
        product_location = ProductLocation(
            product=product,
            location=location,
            quantity=0,
            max_quantity=max_qty
        )
        
        # Add initial quantity (updates total stock too)
        if initial_qty > 0:
            product_location.quantity = initial_qty
            product.total_stock += initial_qty
        
        print(f"\n  Product assigned successfully!")
        print(f"  {product.name} -> {location.location_id}")
        print(f"  Quantity: {product_location.quantity}/{product_location.max_quantity}")
        self.pause()
    
    def _update_product_total_stock(self):
        """Update total stock for a product (Feature 4)."""
        self.print_subheader("Update Product Total Stock")
        
        # Search for product first
        print("  Search for product:")
        print("    1. By SKU")
        print("    2. By Name\n")
        
        search_choice = self.get_int_input("  Select: ", 1, 2)
        
        if search_choice == 1:
            term = self.get_input("  Enter SKU: ")
            product = Product.search_by_sku(term)
        else:
            term = self.get_input("  Enter name: ")
            product = Product.search_by_name(term)
        
        if not product:
            print("  Product not found.")
            self.pause()
            return
        
        self._display_product_details(product)
        
        print(f"\n  Current Total Stock: {product.total_stock}")
        print("    1. Add stock")
        print("    2. Remove stock\n")
        
        action = self.get_int_input("  Select action: ", 1, 2)
        
        if action == 1:
            amount = self.get_int_input("  Amount to add: ", 1)
            product.add_total_stock(amount)
            print(f"\n  Added {amount} units. New total: {product.total_stock}")
        else:
            if product.total_stock == 0:
                print("  No stock to remove.")
            else:
                amount = self.get_int_input(f"  Amount to remove (max {product.total_stock}): ", 1, product.total_stock)
                product.remove_total_stock(amount)
                print(f"\n  Removed {amount} units. New total: {product.total_stock}")
        
        self.pause()
    
    def _update_location_quantity(self):
        """Update quantity at a specific location (Feature 5)."""
        self.print_subheader("Update Location Quantity")
        
        product_loc = self._select_product_location()
        if not product_loc:
            return
        
        # Calculate available stock to distribute
        product = product_loc.product
        total_at_locations = sum(pl.quantity for pl in product.get_locations())
        available_stock = product.total_stock - total_at_locations
        
        print(f"\n  Product: {product_loc.product.name}")
        print(f"  Location: {product_loc.location.location_id}")
        print(f"  Current Quantity: {product_loc.quantity}")
        print(f"  Maximum Quantity: {product_loc.max_quantity}")
        print(f"  Location Capacity: {product_loc.get_available_capacity()}")
        print(f"\n  Total Stock: {product.total_stock}")
        print(f"  At All Locations: {total_at_locations}")
        print(f"  Available to Distribute: {available_stock}")
        
        print("\n    1. Add quantity")
        print("    2. Remove quantity\n")
        
        action = self.get_int_input("  Select action: ", 1, 2)
        
        if action == 1:
            location_capacity = product_loc.get_available_capacity()
            max_add = min(location_capacity, available_stock)
            
            if max_add == 0:
                if location_capacity == 0:
                    print("  Location is at maximum capacity!")
                else:
                    print("  No available stock to distribute!")
                    print(f"  All {product.total_stock} units are already at locations.")
                    print("  Add to total stock first.")
            else:
                if location_capacity < available_stock:
                    print(f"  (Limited by location capacity: {location_capacity})")
                else:
                    print(f"  (Limited by available stock: {available_stock})")
                    
                amount = self.get_int_input(f"  Amount to add (max {max_add}): ", 1, max_add)
                try:
                    product_loc.add_quantity(amount)
                    print(f"\n  Added {amount} units.")
                    print(f"  New quantity: {product_loc.quantity}/{product_loc.max_quantity}")
                except ValueError as e:
                    print(f"\n  ✗ Error: {e}")
        else:
            if product_loc.quantity == 0:
                print("  Location is empty!")
            else:
                amount = self.get_int_input(f"  Amount to remove (max {product_loc.quantity}): ", 1, product_loc.quantity)
                product_loc.remove_quantity(amount)
                print(f"\n  Removed {amount} units.")
                print(f"  New quantity: {product_loc.quantity}/{product_loc.max_quantity}")
        
        self.pause()
    
    def _select_product_location(self) -> Optional[ProductLocation]:
        """Helper to select a product location."""
        all_product_locs = []
        for product in Product._products:
            all_product_locs.extend(product.get_locations())
        
        if not all_product_locs:
            print("  No product locations configured.")
            self.pause()
            return None
        
        print("  Product Locations:")
        for i, pl in enumerate(all_product_locs, 1):
            loc_type = pl.location.location_type.value[:8] if pl.location.location_type else "N/A"
            print(f"    {i}. {pl.product.name} @ {pl.location.location_id} ({loc_type}) - {pl.quantity}/{pl.max_quantity}")
        print()
        
        idx = self.get_int_input("  Select: ", 1, len(all_product_locs))
        return all_product_locs[idx - 1]
    
    def _generate_restock_report(self):
        """Generate restock tasks grouped by category (Feature 6)."""
        self.print_subheader("Restock Report by Category")
        
        # Find salesfloor locations needing restock
        restock_needed: Dict[str, List] = {}
        
        for product in Product._products:
            category = product.category or "Uncategorized"
            
            for pl in product.get_locations():
                if pl.location.location_type == LocationType.SALESFLOOR and pl.needs_restock():
                    # Find backroom location for this product
                    backroom_loc = None
                    for br_pl in product.get_locations():
                        if br_pl.location.location_type == LocationType.BACKROOM and br_pl.quantity > 0:
                            backroom_loc = br_pl
                            break
                    
                    if backroom_loc:
                        if category not in restock_needed:
                            restock_needed[category] = []
                        
                        needed = min(pl.get_available_capacity(), backroom_loc.quantity)
                        restock_needed[category].append({
                            'product': product,
                            'salesfloor': pl,
                            'backroom': backroom_loc,
                            'needed': needed
                        })
        
        if not restock_needed:
            print("  No products need restocking or no backroom stock available.")
            self.pause()
            return
        
        # Display by category (Feature 6)
        print("\n  RESTOCK NEEDED BY CATEGORY:")
        print("  " + "=" * 60)
        
        for category, items in restock_needed.items():
            print(f"\n  [{category.upper()}]")
            print("  " + "-" * 58)
            
            for item in items:
                print(f"    Product: {item['product'].name}")
                print(f"      Backroom Location: {item['backroom'].location.location_id}")
                print(f"        Current Stock: {item['backroom'].quantity}")
                print(f"      Salesfloor Location: {item['salesfloor'].location.location_id}")
                print(f"        Current: {item['salesfloor'].quantity}/{item['salesfloor'].max_quantity}")
                print(f"      --> MOVE {item['needed']} units to salesfloor")
                print()
        
        self.pause()
    
    # --- Employee Management ---
    
    def admin_manage_employees(self):
        """Manage employees."""
        while True:
            self.print_header("MANAGE EMPLOYEES")
            
            options = {
                "1": "View All Employees",
                "2": "Create New Employee",
                "3": "Create New Administrator",
                "0": "Back"
            }
            self.print_menu(options)
            
            choice = input("Select option: ").strip()
            
            if choice == "1":
                self._view_all_employees()
            elif choice == "2":
                self._create_employee()
            elif choice == "3":
                self._create_administrator()
            elif choice == "0":
                break
    
    def _view_all_employees(self):
        """View all employees and administrators."""
        self.print_subheader("All Staff")
        
        print("\n  ADMINISTRATORS:")
        print("  " + "-" * 50)
        for admin in self.administrators:
            status = "ONLINE" if admin.is_logged_in else "offline"
            print(f"    {admin.admin_id}: {admin.name} (Login: {admin.employee_id}) [{status}]")
        
        print("\n  EMPLOYEES:")
        print("  " + "-" * 50)
        for emp in self.employees:
            status = "ONLINE" if emp.is_logged_in else "offline"
            print(f"    {emp.employee_id}: {emp.name} [{status}]")
        
        self.pause()
    
    def _create_employee(self):
        """Create a new employee."""
        self.print_subheader("Create New Employee")
        
        emp_id = self.get_input("  Employee ID (for login): ")
        
        # Check for duplicate
        for emp in self.employees:
            if emp.employee_id == emp_id:
                print("  Employee ID already exists!")
                self.pause()
                return
        
        password = self.get_input("  Password: ")
        name = self.get_input("  Full Name: ")
        
        employee = Employee(employee_id=emp_id, password=password, name=name)
        self.employees.append(employee)
        
        print(f"\n  Employee '{name}' created successfully!")
        print(f"  Login: {emp_id} / {password}")
        self.pause()
    
    def _create_administrator(self):
        """Create a new administrator."""
        self.print_subheader("Create New Administrator")
        
        admin_id = f"ADMIN{len(self.administrators) + 1:03d}"
        emp_id = self.get_input("  Employee ID (for login): ")
        
        # Check for duplicate
        for admin in self.administrators:
            if admin.employee_id == emp_id:
                print("  Employee ID already exists!")
                self.pause()
                return
        
        password = self.get_input("  Password: ")
        name = self.get_input("  Full Name: ")
        
        admin = Administrator(admin_id=admin_id, employee_id=emp_id, password=password, name=name)
        self.administrators.append(admin)
        
        print(f"\n  Administrator '{name}' created successfully!")
        print(f"  Admin ID: {admin_id}")
        print(f"  Login: {emp_id} / {password}")
        self.pause()
    
    # --- Reports ---
    
    def admin_view_reports(self):
        """View system reports."""
        self.print_header("SYSTEM REPORTS")
        
        # Inventory Report
        print("\n  INVENTORY SUMMARY")
        print("  " + "-" * 40)
        print(f"  Total Products:     {len(Product._products)}")
        
        total_stock = sum(p.total_stock for p in Product._products)
        print(f"  Total Stock Units:  {total_stock}")
        
        out_of_stock = [p for p in Product._products if p.total_stock == 0]
        print(f"  Out of Stock:       {len(out_of_stock)}")
        
        low_stock = [p for p in Product._products if 0 < p.total_stock < 10]
        print(f"  Low Stock (<10):    {len(low_stock)}")
        
        if low_stock:
            print("\n  Low Stock Products:")
            for p in low_stock:
                print(f"    - {p.name}: {p.total_stock} units")
        
        # Order Report
        print("\n  ORDER SUMMARY")
        print("  " + "-" * 40)
        
        status_counts = {status: 0 for status in OrderStatus}
        for order in self.orders:
            status_counts[order.status] += 1
        
        for status, count in status_counts.items():
            print(f"  {status.value:<12}: {count}")
        
        print(f"\n  Total Orders: {len(self.orders)}")
        
        self.pause()
    
    def admin_view_orders(self):
        """View all orders."""
        self.print_subheader("All Orders")
        
        if not self.orders:
            print("  No orders in system.")
        else:
            print(f"  {'Order ID':<15} {'Customer':<20} {'Status':<12} {'Items':>6} {'Total':>10}")
            print("  " + "-" * 68)
            for order in self.orders:
                cust_name = order.customer.name[:19] if order.customer else "Guest"
                print(f"  {order.order_id:<15} {cust_name:<20} {order.status.value:<12} {len(order.items):>6} ${order.get_total():>9}")
        
        self.pause()
    
    # ==================== EMPLOYEE PORTAL (Feature 8) ====================
    
    def employee_portal(self):
        """Employee portal - requires employee login."""
        if not isinstance(self.current_user, Employee):
            print("\n  Access Denied. Please login as Employee first.")
            self.pause()
            return
        
        while True:
            self.print_header("EMPLOYEE PORTAL")
            print(f"  Logged in as: {self.current_user.name}\n")
            
            options = {
                "1": "Search Product & Manage Stock",
                "2": "Pick Online Orders",
                "3": "Stow Completed Orders",
                "4": "Retrieve Customer Order (by Name)",
                "5": "Execute Restock",
                "6": "View Pending Orders",
            }
            self.print_menu(options)
            
            print("  --- SESSION ---")
            session_options = {
                "L": "Logout",
                "0": "Back to Main Menu"
            }
            self.print_menu(session_options)
            
            choice = input("Select option: ").strip().upper()
            
            if choice == "1":
                self.employee_search_product()
            elif choice == "2":
                self.employee_pick_orders()
            elif choice == "3":
                self.employee_stow_orders()
            elif choice == "4":
                self.employee_retrieve_order()
            elif choice == "5":
                self.employee_restock()
            elif choice == "6":
                self.employee_view_pending_orders()
            elif choice == "L":
                self._logout()
                return  # Exit portal after logout
            elif choice == "0":
                break
    
    def employee_search_product(self):
        """Employee searches for product and manages stock (Features 2, 3, 4, 5)."""
        self.print_subheader("Search Product & Manage Stock")
        
        print("  Enter product name or SKU to search:")
        search_term = self.get_input("  Search: ")
        
        # Try SKU first, then name
        product = Product.search_by_sku(search_term)
        if not product:
            product = Product.search_by_name(search_term)
        
        if not product:
            print("\n  Product not found.")
            self.pause()
            return
        
        # Product found - show details and management loop
        while True:
            self._display_product_details(product)
            
            print("\n  ═══ STOCK MANAGEMENT ═══")
            print("    1. Add to total stock")
            print("    2. Remove from total stock")
            print("    3. Add stock to a location")
            print("    4. Remove stock from a location")
            print("    0. Back to menu\n")
            
            action = input("  Select action: ").strip()
            
            if action == "1":
                # Add to total stock
                amount = self.get_int_input("  Amount to add: ", 1)
                product.add_total_stock(amount)
                print(f"\n  ✓ Added {amount} units. New total stock: {product.total_stock}")
                self.pause()
                
            elif action == "2":
                # Remove from total stock
                if product.total_stock > 0:
                    amount = self.get_int_input(f"  Amount to remove (max {product.total_stock}): ", 1, product.total_stock)
                    product.remove_total_stock(amount)
                    print(f"\n  ✓ Removed {amount} units. New total stock: {product.total_stock}")
                else:
                    print("\n  ✗ No stock to remove.")
                self.pause()
                
            elif action == "3":
                # Add stock to a specific location
                self._add_stock_to_location(product)
                
            elif action == "4":
                # Remove stock from a specific location
                self._remove_stock_from_location(product)
                
            elif action == "0":
                break
    
    def _add_stock_to_location(self, product):
        """Add stock to a specific product location."""
        locations = product.get_locations()
        
        if not locations:
            print("\n  ✗ No locations assigned to this product.")
            self.pause()
            return
        
        # Calculate current total across all locations
        total_at_locations = sum(pl.quantity for pl in locations)
        available_from_total = product.total_stock - total_at_locations
        
        if available_from_total <= 0:
            print("\n  ✗ Cannot add stock to locations!")
            print(f"    Total stock: {product.total_stock}")
            print(f"    Already at locations: {total_at_locations}")
            print(f"    Available to distribute: 0")
            print("\n    Add to total stock first before distributing to locations.")
            self.pause()
            return
        
        print("\n  ═══ ADD STOCK TO LOCATION ═══")
        print(f"\n  Total Stock: {product.total_stock}")
        print(f"  Currently at locations: {total_at_locations}")
        print(f"  Available to distribute: {available_from_total}")
        print("\n  Select location:")
        for i, pl in enumerate(locations, 1):
            loc_type = pl.location.location_type.value
            capacity = pl.get_available_capacity()
            print(f"    {i}. [{loc_type}] {pl.location.location_id}")
            print(f"       {pl.location.get_full_location_string()}")
            print(f"       Current: {pl.quantity}/{pl.max_quantity} (Space for {capacity} more)")
        print()
        
        loc_idx = self.get_int_input("  Select location: ", 1, len(locations))
        pl = locations[loc_idx - 1]
        
        # Calculate maximum we can add (limited by both location capacity AND available stock)
        location_capacity = pl.get_available_capacity()
        max_add = min(location_capacity, available_from_total)
        
        if max_add <= 0:
            if location_capacity <= 0:
                print("\n  ✗ Location is full! Cannot add more stock.")
            else:
                print("\n  ✗ No available stock to distribute!")
                print(f"    All {product.total_stock} units are already at locations.")
                print("    Add to total stock first.")
            self.pause()
            return
        
        print(f"\n  Location: {pl.location.location_id}")
        print(f"  Current stock: {pl.quantity}/{pl.max_quantity}")
        print(f"  Location capacity: {location_capacity}")
        print(f"  Available from total stock: {available_from_total}")
        print(f"  Maximum you can add: {max_add}")
        
        amount = self.get_int_input(f"  Amount to add (max {max_add}): ", 1, max_add)
        
        try:
            pl.add_quantity(amount)
            print(f"\n  ✓ Added {amount} units to {pl.location.location_id}")
            print(f"    New quantity: {pl.quantity}/{pl.max_quantity}")
        except ValueError as e:
            print(f"\n  ✗ Error: {e}")
        
        self.pause()
    
    def _remove_stock_from_location(self, product):
        """Remove stock from a specific product location."""
        locations = product.get_locations()
        
        if not locations:
            print("\n  ✗ No locations assigned to this product.")
            self.pause()
            return
        
        # Filter to locations with stock
        locations_with_stock = [pl for pl in locations if pl.quantity > 0]
        
        if not locations_with_stock:
            print("\n  ✗ All locations are empty!")
            self.pause()
            return
        
        print("\n  ═══ REMOVE STOCK FROM LOCATION ═══")
        print("\n  Select location:")
        for i, pl in enumerate(locations_with_stock, 1):
            loc_type = pl.location.location_type.value
            print(f"    {i}. [{loc_type}] {pl.location.location_id}")
            print(f"       {pl.location.get_full_location_string()}")
            print(f"       Current: {pl.quantity}/{pl.max_quantity}")
        print()
        
        loc_idx = self.get_int_input("  Select location: ", 1, len(locations_with_stock))
        pl = locations_with_stock[loc_idx - 1]
        
        print(f"\n  Location: {pl.location.location_id}")
        print(f"  Current stock: {pl.quantity}/{pl.max_quantity}")
        
        amount = self.get_int_input(f"  Amount to remove (max {pl.quantity}): ", 1, pl.quantity)
        pl.remove_quantity(amount)
        
        print(f"\n  ✓ Removed {amount} units from {pl.location.location_id}")
        print(f"    New quantity: {pl.quantity}/{pl.max_quantity}")
        self.pause()
    
    def employee_view_pending_orders(self):
        """View orders waiting to be picked."""
        self.print_subheader("Pending Orders")
        
        pending = [o for o in self.orders if o.status == OrderStatus.PENDING]
        
        if not pending:
            print("  No orders waiting to be picked.")
        else:
            for order in pending:
                print(f"\n  {order.order_id} - {order.customer.name if order.customer else 'Guest'}")
                print(f"  Placed: {order.order_date.strftime('%Y-%m-%d %H:%M')}")
                print(f"  Items: {len(order.items)}")
                for item in order.items:
                    print(f"    - {item.quantity}x {item.product.name}")
        
        self.pause()
    
    def employee_pick_orders(self):
        """Pick an online order (Feature 10)."""
        self.print_subheader("Pick Online Order")
        
        pending = [o for o in self.orders if o.status == OrderStatus.PENDING]
        
        if not pending:
            print("  No orders available for picking.")
            self.pause()
            return
        
        print("  Pending Orders:")
        for i, order in enumerate(pending, 1):
            cust_name = order.customer.name if order.customer else "Guest"
            print(f"    {i}. {order.order_id} - {cust_name} ({len(order.items)} items)")
        print()
        
        idx = self.get_int_input("  Select order to pick: ", 1, len(pending))
        order = pending[idx - 1]
        
        # Start picking session
        session = PickingSession(employee=self.current_user)
        session.orders.append(order)
        order.start_picking()
        self.picking_sessions.append(session)
        
        print(f"\n  Starting picking session: {session.session_id}")
        print(f"  Order: {order.order_id}")
        print(f"  Customer: {order.customer.name if order.customer else 'Guest'}")
        print("\n" + "=" * 60)
        
        # Create a working list of items (to handle skipping)
        items_to_pick = list(order.items)
        skipped_items = []
        
        while items_to_pick or skipped_items:
            # If main list empty but we have skipped items, move them back
            if not items_to_pick and skipped_items:
                print("\n  --- Processing Skipped Items ---")
                items_to_pick = skipped_items
                skipped_items = []
            
            if not items_to_pick:
                break
            
            item = items_to_pick.pop(0)
            
            if item.status != ItemStatus.PENDING:
                continue
            
            print(f"\n  ITEM: {item.quantity}x {item.product.name}")
            print(f"  SKU: {item.product.sku}")
            
            # Show locations where product can be found (Feature 10)
            locations = item.product.get_locations()
            sf_locations = [pl for pl in locations if pl.location.location_type == LocationType.SALESFLOOR and pl.quantity > 0]
            
            if sf_locations:
                print("\n  PICK FROM:")
                for pl in sf_locations:
                    print(f"    Location: {pl.location.location_id}")
                    print(f"    Path: {pl.location.get_full_location_string()}")
                    print(f"    Available: {pl.quantity}")
            else:
                print("\n  WARNING: No salesfloor stock available!")
            
            print("\n  Actions:")
            print("    [F] FOUND - Item picked successfully")
            print("    [N] NOT FOUND - Remove item from order")
            print("    [S] SKIP - Move to end of list")
            
            while True:
                action = input("\n  Action: ").strip().upper()
                
                if action == "F":
                    # Mark as found and reduce inventory
                    item.mark_found()
                    
                    # Remove from first available salesfloor location
                    remaining = item.quantity
                    for pl in sf_locations:
                        if remaining <= 0:
                            break
                        take = min(pl.quantity, remaining)
                        if take > 0:
                            pl.remove_quantity(take)
                            remaining -= take
                    
                    print(f"  --> Item marked as FOUND")
                    break
                
                elif action == "N":
                    # Mark as not found - remove from order
                    item.mark_not_found()
                    print(f"  --> Item marked as NOT FOUND - will be removed from order")
                    break
                
                elif action == "S":
                    # Skip - add to end of skipped list
                    skipped_items.append(item)
                    print(f"  --> Item SKIPPED - moved to end of list")
                    break
                
                else:
                    print("  Invalid action. Enter F, N, or S.")
        
        # Complete the session
        session.end_time = datetime.now()
        
        # Remove NOT FOUND items from order
        order.items = [item for item in order.items if item.status != ItemStatus.NOTFOUND]
        
        # Check if any items remain
        if order.items:
            order.mark_ready()
            print("\n" + "=" * 60)
            print("  PICKING COMPLETE!")
            print(f"  Order {order.order_id} is READY for stowing.")
            print(f"  Items collected: {len(order.items)}")
        else:
            # No items left - cancel order
            order.status = OrderStatus.COMPLETED
            print("\n" + "=" * 60)
            print("  All items were NOT FOUND.")
            print("  Order has been cancelled.")
        
        self.pause()
    
    def employee_stow_orders(self):
        """Stow completed orders at front of store (Feature 11)."""
        self.print_subheader("Stow Orders at Pickup Location")
        
        ready = [o for o in self.orders if o.status == OrderStatus.READY]
        
        if not ready:
            print("  No orders ready for stowing.")
            self.pause()
            return
        
        # Get pickup locations (front of store)
        pickup_locs = [l for l in self.locations if l.location_type == LocationType.ORDERPICKUP]
        
        if not pickup_locs:
            print("  No pickup locations available. Admin must create ORDER PICKUP locations.")
            self.pause()
            return
        
        print("  Orders Ready for Stowing:")
        for i, order in enumerate(ready, 1):
            cust_name = order.customer.name if order.customer else "Guest"
            print(f"    {i}. {order.order_id} - {cust_name} ({len(order.items)} items)")
        print()
        
        idx = self.get_int_input("  Select order to stow: ", 1, len(ready))
        order = ready[idx - 1]
        
        print(f"\n  ORDER PICKUP LOCATIONS (Front of Store - Aisle F1):")
        for i, loc in enumerate(pickup_locs, 1):
            # Check if location is in use
            in_use = any(o.stow_location == loc for o in self.orders if o.status == OrderStatus.READY and o != order)
            status = "(IN USE)" if in_use else "(AVAILABLE)"
            print(f"    {i}. {loc.location_id}")
            print(f"       {loc.get_full_location_string()} {status}")
        print()
        
        loc_idx = self.get_int_input("  Select pickup location: ", 1, len(pickup_locs))
        location = pickup_locs[loc_idx - 1]
        
        order.assign_stow_location(location)
        
        print(f"\n  Order stowed successfully!")
        print(f"  Order: {order.order_id}")
        print(f"  Customer: {order.customer.name if order.customer else 'Guest'}")
        print(f"  Location: {location.location_id}")
        print(f"  Path: {location.get_full_location_string()}")
        print("\n  Customer can now pick up their order by giving their name.")
        
        self.pause()
    
    def employee_retrieve_order(self):
        """Retrieve order by customer name (Feature 11)."""
        self.print_subheader("Retrieve Customer Order")
        
        print("  Customer will provide their name to retrieve their order.\n")
        customer_name = self.get_input("  Enter customer name: ")
        
        # Find ready orders for this customer
        matching_orders = []
        for order in self.orders:
            if order.status == OrderStatus.READY and order.customer:
                if customer_name.lower() in order.customer.name.lower():
                    matching_orders.append(order)
        
        if not matching_orders:
            print(f"\n  No ready orders found for '{customer_name}'.")
            self.pause()
            return
        
        print(f"\n  Orders found for '{customer_name}':")
        for i, order in enumerate(matching_orders, 1):
            loc_str = order.stow_location.location_id if order.stow_location else "Not stowed"
            print(f"\n    {i}. Order {order.order_id}")
            print(f"       Location: {loc_str}")
            if order.stow_location:
                print(f"       Path: {order.stow_location.get_full_location_string()}")
            print(f"       Items:")
            for item in order.items:
                print(f"         - {item.quantity}x {item.product.name}")
            print(f"       Total: ${order.get_total()}")
        print()
        
        idx = self.get_int_input("  Select order to retrieve: ", 1, len(matching_orders))
        order = matching_orders[idx - 1]
        
        if order.stow_location:
            print(f"\n  RETRIEVE ORDER FROM:")
            print(f"  Location: {order.stow_location.location_id}")
            print(f"  Path: {order.stow_location.get_full_location_string()}")
        
        if self.get_yes_no("\n  Hand order to customer and mark as picked up? (yes/no): "):
            order.complete()
            print(f"\n  Order {order.order_id} marked as COMPLETED.")
            print("  Thank you for shopping with us!")
        
        self.pause()
    
    def employee_restock(self):
        """Execute restock from backroom to salesfloor (Feature 6)."""
        self.print_subheader("Execute Restock")
        
        # Find items needing restock
        restock_items = []
        
        for product in Product._products:
            for sf_pl in product.get_locations():
                if sf_pl.location.location_type == LocationType.SALESFLOOR and sf_pl.needs_restock():
                    # Find backroom stock
                    for br_pl in product.get_locations():
                        if br_pl.location.location_type == LocationType.BACKROOM and br_pl.quantity > 0:
                            needed = min(sf_pl.get_available_capacity(), br_pl.quantity)
                            if needed > 0:
                                restock_items.append({
                                    'product': product,
                                    'salesfloor': sf_pl,
                                    'backroom': br_pl,
                                    'needed': needed
                                })
                            break
        
        if not restock_items:
            print("  No restocking needed or no backroom stock available.")
            self.pause()
            return
        
        print("  Items Needing Restock:")
        print("  " + "-" * 60)
        
        for i, item in enumerate(restock_items, 1):
            print(f"    {i}. {item['product'].name} ({item['product'].category})")
            print(f"       From Backroom: {item['backroom'].location.location_id} (has {item['backroom'].quantity})")
            print(f"       To Salesfloor: {item['salesfloor'].location.location_id} ({item['salesfloor'].quantity}/{item['salesfloor'].max_quantity})")
            print(f"       Move: {item['needed']} units")
        print()
        
        idx = self.get_int_input("  Select item to restock (0 to cancel): ", 0, len(restock_items))
        
        if idx == 0:
            return
        
        item = restock_items[idx - 1]
        
        # Execute: remove from backroom, add to salesfloor
        print(f"\n  Moving {item['needed']} units of {item['product'].name}...")
        print(f"  From: {item['backroom'].location.get_full_location_string()}")
        print(f"  To: {item['salesfloor'].location.get_full_location_string()}")
        
        item['backroom'].remove_quantity(item['needed'])
        item['salesfloor'].quantity += item['needed']
        item['product'].add_total_stock(item['needed'])  # Re-add since remove_quantity deducted
        
        print(f"\n  Restock completed!")
        print(f"  Backroom now: {item['backroom'].quantity}")
        print(f"  Salesfloor now: {item['salesfloor'].quantity}/{item['salesfloor'].max_quantity}")
        
        self.pause()
    
    # ==================== CUSTOMER PORTAL (Feature 7) ====================
    
    def customer_portal(self):
        """Customer portal."""
        if not isinstance(self.current_user, Customer):
            print("\n  Please login as Customer first.")
            self.pause()
            return
        
        while True:
            self.print_header("CUSTOMER PORTAL")
            print(f"  Welcome, {self.current_user.name}!\n")
            
            options = {
                "1": "Browse Products",
                "2": "Create New Order",
                "3": "View My Orders",
                "4": "Track Order / Pickup",
            }
            self.print_menu(options)
            
            print("  --- SESSION ---")
            session_options = {
                "L": "Logout",
                "0": "Back to Main Menu"
            }
            self.print_menu(session_options)
            
            choice = input("Select option: ").strip().upper()
            
            if choice == "1":
                self.customer_browse_products()
            elif choice == "2":
                self.customer_create_order()
            elif choice == "3":
                self.customer_view_orders()
            elif choice == "4":
                self.customer_track_order()
            elif choice == "L":
                self._logout()
                return  # Exit portal after logout
            elif choice == "0":
                break
    
    def customer_browse_products(self):
        """Customer browses available products (Feature 7)."""
        self.print_subheader("Browse Products")
        
        available = [p for p in Product._products if p.total_stock > 0]
        
        if not available:
            print("  No products currently available.")
        else:
            # Group by category
            categories = {}
            for p in available:
                cat = p.category or "Other"
                if cat not in categories:
                    categories[cat] = []
                categories[cat].append(p)
            
            for category, products in sorted(categories.items()):
                print(f"\n  [{category.upper()}]")
                print("  " + "-" * 50)
                for p in products:
                    print(f"    {p.name}")
                    print(f"      SKU: {p.sku} | Price: ${p.price} | In Stock: {p.total_stock}")
        
        self.pause()
    
    def customer_create_order(self):
        """Customer creates an online order (Feature 7)."""
        self.print_subheader("Create New Order")
        
        available = [p for p in Product._products if p.total_stock > 0]
        
        if not available:
            print("  No products available to order.")
            self.pause()
            return
        
        order = OnlineOrder(customer=self.current_user)
        self.orders.append(order)
        self.current_user.orders.append(order)
        
        while True:
            print(f"\n  === Order {order.order_id} ===")
            
            if order.items:
                print("\n  Current Cart:")
                for item in order.items:
                    line_total = float(item.product.price) * item.quantity
                    print(f"    {item.quantity}x {item.product.name} @ ${item.product.price} = ${line_total:.2f}")
                print(f"\n  Cart Total: ${order.get_total()}")
            else:
                print("\n  Cart is empty.")
            
            print("\n  Available Products:")
            for i, p in enumerate(available, 1):
                print(f"    {i}. {p.name} - ${p.price} ({p.total_stock} in stock)")
            
            print("\n  Actions:")
            print("    [A] Add product to cart")
            print("    [R] Remove product from cart")
            print("    [C] Checkout / Purchase order")
            print("    [X] Cancel order")
            
            action = input("\n  Action: ").strip().upper()
            
            if action == "A":
                prod_idx = self.get_int_input("  Product number: ", 1, len(available))
                product = available[prod_idx - 1]
                max_qty = min(product.total_stock, 99)
                quantity = self.get_int_input(f"  Quantity (1-{max_qty}): ", 1, max_qty)
                order.add_item(product, quantity)
                print(f"\n  Added {quantity}x {product.name} to cart!")
            
            elif action == "R":
                if not order.items:
                    print("  Cart is empty.")
                    continue
                
                print("\n  Cart Items:")
                for i, item in enumerate(order.items, 1):
                    print(f"    {i}. {item.quantity}x {item.product.name}")
                
                item_idx = self.get_int_input("  Remove item number: ", 1, len(order.items))
                removed_item = order.items[item_idx - 1]
                order.items.remove(removed_item)
                print(f"\n  Removed {removed_item.product.name} from cart.")
            
            elif action == "C":
                if not order.items:
                    print("  Cannot checkout with empty cart!")
                    continue
                
                print(f"\n  === ORDER SUMMARY ===")
                for item in order.items:
                    print(f"    {item.quantity}x {item.product.name} = ${item.get_line_total():.2f}")
                print(f"\n  TOTAL: ${order.get_total()}")
                
                if self.get_yes_no("\n  Confirm purchase? (yes/no): "):
                    order.purchase()
                    print(f"\n  Order placed successfully!")
                    print(f"  Order ID: {order.order_id}")
                    print("  You will be notified when your order is ready for pickup.")
                    print("  Give your name to an employee at the Order Pickup area.")
                    self.pause()
                    return
            
            elif action == "X":
                self.orders.remove(order)
                self.current_user.orders.remove(order)
                print("\n  Order cancelled.")
                self.pause()
                return
    
    def customer_view_orders(self):
        """View customer's order history."""
        self.print_subheader("My Orders")
        
        if not self.current_user.orders:
            print("  You have no orders.")
        else:
            for order in self.current_user.orders:
                print(f"\n  Order: {order.order_id}")
                print(f"  Date: {order.order_date.strftime('%Y-%m-%d %H:%M')}")
                print(f"  Status: {order.status.value}")
                print(f"  Items:")
                for item in order.items:
                    status_icon = "[OK]" if item.status == ItemStatus.FOUND else "[..]"
                    print(f"    {status_icon} {item.quantity}x {item.product.name}")
                print(f"  Total: ${order.get_total()}")
                
                if order.stow_location:
                    print(f"  Pickup Location: {order.stow_location.get_full_location_string()}")
        
        self.pause()
    
    def customer_track_order(self):
        """Track order status and pickup info."""
        self.print_subheader("Track Order / Pickup")
        
        active_orders = [o for o in self.current_user.orders if o.status != OrderStatus.COMPLETED]
        
        if not active_orders:
            print("  No active orders.")
            self.pause()
            return
        
        print("  Active Orders:")
        for i, order in enumerate(active_orders, 1):
            print(f"    {i}. {order.order_id} - {order.status.value}")
        print()
        
        idx = self.get_int_input("  Select order: ", 1, len(active_orders))
        order = active_orders[idx - 1]
        
        print(f"\n  === Order {order.order_id} ===")
        print(f"  Status: {order.status.value}")
        
        # Status messages
        if order.status == OrderStatus.PENDING:
            print("\n  Your order is waiting to be picked by our staff.")
            print("  Please check back later.")
        
        elif order.status == OrderStatus.PICKING:
            print("\n  An employee is currently collecting your items!")
            print("  Your order will be ready soon.")
        
        elif order.status == OrderStatus.READY:
            print("\n  YOUR ORDER IS READY FOR PICKUP!")
            
            if order.stow_location:
                print(f"\n  Pickup Location (Front of Store):")
                print(f"    {order.stow_location.get_full_location_string()}")
            
            print("\n  Items:")
            for item in order.items:
                print(f"    - {item.quantity}x {item.product.name}")
            
            print(f"\n  Total: ${order.get_total()}")
            print("\n  Please visit the Order Pickup area at the front of the store.")
            print("  Give your name to an employee to collect your order.")
        
        self.pause()
    
    # ==================== SYSTEM OVERVIEW ====================
    
    def view_system_overview(self):
        """View complete system overview."""
        self.print_header("SYSTEM OVERVIEW")
        
        print(f"\n  PRODUCTS: {len(Product._products)}")
        for p in Product._products[:5]:
            print(f"    - {p.name} (Stock: {p.total_stock})")
        if len(Product._products) > 5:
            print(f"    ... and {len(Product._products) - 5} more")
        
        print(f"\n  LOCATIONS: {len(self.locations)}")
        for loc_type in LocationType:
            count = len([l for l in self.locations if l.location_type == loc_type])
            print(f"    {loc_type.value}: {count}")
        
        print(f"\n  CUSTOMERS: {len(self.customers)}")
        for c in self.customers[:3]:
            print(f"    - {c.name}")
        
        print(f"\n  EMPLOYEES: {len(self.employees)}")
        for e in self.employees[:3]:
            print(f"    - {e.name}")
        
        print(f"\n  ADMINISTRATORS: {len(self.administrators)}")
        for a in self.administrators:
            print(f"    - {a.name}")
        
        print(f"\n  ORDERS: {len(self.orders)}")
        for status in OrderStatus:
            count = len([o for o in self.orders if o.status == status])
            if count > 0:
                print(f"    {status.value}: {count}")
        
        self.pause()


# ==================== MAIN ENTRY POINT ====================

if __name__ == "__main__":
    app = StoreApplication()
    app.run()
