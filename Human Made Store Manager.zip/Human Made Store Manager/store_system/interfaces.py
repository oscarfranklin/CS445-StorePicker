#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Interfaces for the Store Inventory and Order Management System.
Uses Abstract Base Classes to define interfaces.
"""

from abc import ABC, abstractmethod


class CustomerPortal(ABC):
    """
    Interface for customer-facing operations.
    Implemented by Customer class.
    """
    
    @abstractmethod
    def browse_products(self):
        """Browse available products."""
        pass
    
    @abstractmethod
    def create_order(self):
        """Create a new online order."""
        pass


class StoreSystem(ABC):
    """
    Interface for store system operations.
    Implemented by Employee and Administrator classes.
    """
    
    @abstractmethod
    def login(self, employee_id: str, password: str) -> bool:
        """Authenticate into the store system."""
        pass
