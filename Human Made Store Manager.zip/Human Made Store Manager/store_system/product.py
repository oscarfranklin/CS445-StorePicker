#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Product class for the Store Inventory and Order Management System.
"""

from decimal import Decimal
from typing import Optional, List, TYPE_CHECKING

if TYPE_CHECKING:
    from product_location import ProductLocation


class Product:
    """
    Represents a product in the store inventory.
    
    Attributes:
        sku: Stock Keeping Unit - unique product identifier
        name: Product name
        description: Product description
        category: Product category
        price: Product price as decimal
        total_stock: Total quantity across all locations
    """
    
    # Class-level product registry for search functionality
    _products: List['Product'] = []
    
    def __init__(
        self,
        sku: str = None,
        name: str = None,
        description: str = None,
        category: str = None,
        price: Decimal = None,
        total_stock: int = 0
    ):
        self.sku = sku
        self.name = name
        self.description = description
        self.category = category
        self.price = price if price is not None else Decimal("0.00")
        self.total_stock = total_stock
        self._locations: List['ProductLocation'] = []
        
        # Register product for search
        Product._products.append(self)
    
    @classmethod
    def search_by_name(cls, name: str) -> Optional['Product']:
        """
        Search for a product by name.
        
        Args:
            name: Product name to search for
            
        Returns:
            Product if found, None otherwise
        """
        for product in cls._products:
            if product.name and name.lower() in product.name.lower():
                return product
        return None
    
    @classmethod
    def search_by_sku(cls, sku: str) -> Optional['Product']:
        """
        Search for a product by SKU.
        
        Args:
            sku: SKU to search for
            
        Returns:
            Product if found, None otherwise
        """
        for product in cls._products:
            if product.sku == sku:
                return product
        return None
    
    def get_info(self) -> dict:
        """
        Get product information as a dictionary.
        
        Returns:
            Dictionary containing product details
        """
        return {
            "sku": self.sku,
            "name": self.name,
            "description": self.description,
            "category": self.category,
            "price": str(self.price),
            "total_stock": self.total_stock
        }
    
    def add_total_stock(self, quantity: int) -> None:
        """
        Add to total stock quantity.
        
        Args:
            quantity: Amount to add
        """
        if quantity < 0:
            raise ValueError("Quantity must be non-negative")
        self.total_stock += quantity
    
    def remove_total_stock(self, quantity: int) -> None:
        """
        Remove from total stock quantity.
        
        Args:
            quantity: Amount to remove
            
        Raises:
            ValueError: If quantity would result in negative stock
        """
        if quantity < 0:
            raise ValueError("Quantity must be non-negative")
        if quantity > self.total_stock:
            raise ValueError("Cannot remove more than available stock")
        self.total_stock -= quantity
    
    def add_location(self, location: 'ProductLocation') -> None:
        """
        Associate a ProductLocation with this product.
        
        Args:
            location: ProductLocation to associate
        """
        if location not in self._locations:
            self._locations.append(location)
    
    def get_locations(self) -> List['ProductLocation']:
        """
        Get all locations where this product is stored.
        
        Returns:
            List of ProductLocation objects
        """
        return self._locations.copy()
    
    def __repr__(self) -> str:
        return f"Product(sku='{self.sku}', name='{self.name}', price={self.price})"
    
    def __str__(self) -> str:
        return f"{self.name} (SKU: {self.sku}) - ${self.price}"
