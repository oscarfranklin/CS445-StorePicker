#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Enumerations for the Store Inventory and Order Management System.
"""

from enum import Enum


class LocationType(Enum):
    """Types of locations within the store."""
    SALESFLOOR = "SALESFLOOR"
    BACKROOM = "BACKROOM"
    ORDERPICKUP = "ORDERPICKUP"


class OrderStatus(Enum):
    """Status states for online orders."""
    PENDING = "PENDING"
    PICKING = "PICKING"
    READY = "READY"
    COMPLETED = "COMPLETED"


class ItemStatus(Enum):
    """Status states for individual order items."""
    PENDING = "PENDING"
    FOUND = "FOUND"
    NOTFOUND = "NOTFOUND"
    SKIPPED = "SKIPPED"
