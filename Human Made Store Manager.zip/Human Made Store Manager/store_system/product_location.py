#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
ProductLocation class for the Store Inventory and Order Management System.
Represents the association between a Product and a Location with quantity tracking.
"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from product import Product
    from location import Location


class ProductLocation:
    """
    Represents the placement of a product at a specific location.
    This is an association class linking Product and Location.
    
    Attributes:
        product: The product at this location
        location: The physical location
        quantity: Current quantity at this location
        max_quantity: Maximum capacity at this location
    """
    
    def __init__(
        self,
        product: 'Product' = None,
        location: 'Location' = None,
        quantity: int = 0,
        max_quantity: int = 0
    ):
        self.product = product
        self.location = location
        self.quantity = quantity
        self.max_quantity = max_quantity
        
        # Register with product and location
        if product:
            product.add_location(self)
        if location:
            location.add_product_location(self)
    
    def add_quantity(self, amount: int, validate_total_stock: bool = True) -> None:
        """
        Add quantity to this location.
        
        Args:
            amount: Amount to add
            validate_total_stock: If True, validate that sum of locations won't exceed total stock
            
        Raises:
            ValueError: If amount is negative, would exceed max_quantity, or would exceed total stock
        """
        if amount < 0:
            raise ValueError("Amount must be non-negative")
        
        new_quantity = self.quantity + amount
        if self.max_quantity > 0 and new_quantity > self.max_quantity:
            raise ValueError(
                f"Cannot add {amount} units. Would exceed max capacity of {self.max_quantity}. "
                f"Current: {self.quantity}, Max additional: {self.max_quantity - self.quantity}"
            )
        
        # Validate against total stock
        if validate_total_stock and self.product:
            total_at_locations = sum(pl.quantity for pl in self.product.get_locations())
            available = self.product.total_stock - total_at_locations
            if amount > available:
                raise ValueError(
                    f"Cannot add {amount} units. Would exceed total stock. "
                    f"Total stock: {self.product.total_stock}, "
                    f"At locations: {total_at_locations}, "
                    f"Available to distribute: {available}"
                )
        
        self.quantity = new_quantity
    
    def remove_quantity(self, amount: int) -> None:
        """
        Remove quantity from this location.
        
        Args:
            amount: Amount to remove
            
        Raises:
            ValueError: If amount is negative or exceeds available quantity
        """
        if amount < 0:
            raise ValueError("Amount must be non-negative")
        if amount > self.quantity:
            raise ValueError(
                f"Cannot remove {amount} units. Only {self.quantity} available at this location."
            )
        
        self.quantity -= amount
    
    def needs_restock(self) -> bool:
        """
        Check if this location needs restocking.
        
        Returns:
            True if quantity is below a threshold (e.g., 25% of max)
        """
        if self.max_quantity <= 0:
            return False
        
        threshold = self.max_quantity * 0.25
        return self.quantity < threshold
    
    def get_available_capacity(self) -> int:
        """
        Get remaining capacity at this location.
        
        Returns:
            Number of units that can still be added (based on max_quantity only)
        """
        if self.max_quantity <= 0:
            return float('inf')
        return max(0, self.max_quantity - self.quantity)
    
    def get_available_to_add(self) -> int:
        """
        Get the maximum quantity that can be added to this location.
        This considers both location capacity AND available undistributed stock.
        
        Returns:
            Number of units that can be added
        """
        location_capacity = self.get_available_capacity()
        
        if not self.product:
            return location_capacity
        
        # Calculate available undistributed stock
        total_at_locations = sum(pl.quantity for pl in self.product.get_locations())
        available_stock = self.product.total_stock - total_at_locations
        
        return min(location_capacity, available_stock)
    
    def get_fill_percentage(self) -> float:
        """
        Get the fill percentage of this location.
        
        Returns:
            Percentage filled (0-100)
        """
        if self.max_quantity <= 0:
            return 0.0
        return (self.quantity / self.max_quantity) * 100
    
    def __repr__(self) -> str:
        product_name = self.product.name if self.product else "None"
        location_id = self.location.location_id if self.location else "None"
        return f"ProductLocation(product='{product_name}', location='{location_id}', qty={self.quantity})"
    
    def __str__(self) -> str:
        product_name = self.product.name if self.product else "Unknown Product"
        location_str = str(self.location) if self.location else "Unknown Location"
        return f"{product_name} @ {location_str}: {self.quantity}/{self.max_quantity}"
