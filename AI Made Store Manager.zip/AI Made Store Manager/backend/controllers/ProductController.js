const Product = require("../models/Product");
const Inventory = require("../models/Inventory");

module.exports = {
    async getAll(req, res) {
        const products = await Product.findAll({ include: Inventory });
        res.json(products);
    }
};
