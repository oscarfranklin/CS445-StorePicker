const StoreSection = require("../models/StoreSection");
const LoggingService = require("../services/LoggingService");

module.exports = {
    async updateSection(req, res) {
        const { id, name } = req.body;

        await StoreSection.update({ name }, { where: { id } });

        LoggingService.log("Updated store section", req.user.id);

        res.json({ success: true });
    }
};
