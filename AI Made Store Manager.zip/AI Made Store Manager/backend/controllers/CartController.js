const Cart = require("../models/Cart");
const CartItem = require("../models/CartItem");
const Inventory = require("../models/Inventory");

module.exports = {
    async addToCart(req, res) {
        const { productId, quantity } = req.body;

        const inventory = await Inventory.findOne({ where: { ProductId: productId } });

        if (inventory.quantity < quantity)
            return res.status(400).json({ error: "Out of stock" });

        const cart = await Cart.findOne({ where: { UserId: req.user.id } });

        await CartItem.create({
            CartId: cart.id,
            ProductId: productId,
            quantity
        });

        res.json({ success: true });
    }
};
