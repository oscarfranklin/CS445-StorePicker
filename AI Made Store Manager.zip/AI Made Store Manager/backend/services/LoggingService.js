const AuditLog = require("../models/AuditLog");

module.exports = {
    log(action, user) {
        AuditLog.create({ action, user });
    }
};
