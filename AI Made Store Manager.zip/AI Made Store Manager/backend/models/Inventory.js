const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");
const Product = require("./Product");

const Inventory = sequelize.define("Inventory", {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    quantity: { type: DataTypes.INTEGER, defaultValue: 0 }
});

Product.hasOne(Inventory, { onDelete: "CASCADE" });
Inventory.belongsTo(Product);

module.exports = Inventory;
