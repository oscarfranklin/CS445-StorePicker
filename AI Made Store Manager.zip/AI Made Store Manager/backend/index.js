// index.js - Basic Express server test
const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Test route
app.get('/', (req, res) => {
  res.json({ 
    message: 'Grocery Store Management API is running!',
    endpoints: [
      '/api/products',
      '/api/users',
      '/api/inventory'
    ]
  });
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`📁 Main file: ${__filename}`);
});