const router = require("express").Router();
const auth = require("../middleware/authMiddleware");
const CartController = require("../controllers/CartController");

router.post("/add", auth, CartController.addToCart);

module.exports = router;
