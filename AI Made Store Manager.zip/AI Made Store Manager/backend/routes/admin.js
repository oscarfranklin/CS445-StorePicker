const router = require("express").Router();
const auth = require("../middleware/authMiddleware");
const manager = require("../middleware/managerMiddleware");
const AdminController = require("../controllers/AdminController");

router.post("/section/update", auth, manager, AdminController.updateSection);

module.exports = router;
