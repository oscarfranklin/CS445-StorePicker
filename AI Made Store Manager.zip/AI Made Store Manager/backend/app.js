const express = require("express");
const cors = require("cors");
const sequelize = require("./config/database");

const app = express();

app.use(cors());
app.use(express.json());

// Routes
app.use("/auth", require("./routes/auth"));
app.use("/products", require("./routes/products"));
app.use("/cart", require("./routes/cart"));
app.use("/admin", require("./routes/admin"));

sequelize.sync().then(() => {
    console.log("Database synced");
});

app.listen(3000, () => console.log("Backend running on port 3000"));
