async function loadProducts() {
    const res = await fetch("http://localhost:3000/products");
    const data = await res.json();

    document.getElementById("products").innerHTML =
        data.map(p => `<p>${p.name} — $${p.price} (Stock: ${p.Inventory.quantity})</p>`).join("");
}

loadProducts();
