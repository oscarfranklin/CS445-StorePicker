async function addToCart() {
    const productId = document.getElementById("productId").value;
    const qty = document.getElementById("qty").value;

    const res = await fetch("http://localhost:3000/cart/add", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": localStorage.getItem("token")
        },
        body: JSON.stringify({ productId, quantity: qty })
    });

    alert("Item added");
}
