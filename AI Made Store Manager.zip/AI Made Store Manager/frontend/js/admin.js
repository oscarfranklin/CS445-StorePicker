async function updateSection() {
    const id = document.getElementById("sectionId").value;
    const name = document.getElementById("sectionName").value;

    const res = await fetch("http://localhost:3000/admin/section/update", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": localStorage.getItem("token")
        },
        body: JSON.stringify({ id, name })
    });

    alert("Section updated");
}
